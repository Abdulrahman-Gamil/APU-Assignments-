﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace LECTURER
{
    internal class AdditionalCoachingRequests
    {
        private string StudentName;
        private string Module;
        private string ApprovalStatus;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        AdditionalCoachingRequests(string s, string m, string ApprovalStatus = "Pending")
        {
            StudentName = s;
            Module = m;
        }

        public static ArrayList viewRequests()
        {
            ArrayList r = new ArrayList();
           
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Student, Module FROM CoachingRequest WHERE ApprovalStatus IS NULL OR ApprovalStatus = 'Pending'", con);
            SqlDataReader rd = cmd.ExecuteReader();

            while (rd.Read())
            {
                string request = rd.GetString(0) + " has requested to join " + rd.GetString(1) + " module for additional coaching";
                r.Add(request);
            }
            con.Close();
            return r;
        }
    }
}
