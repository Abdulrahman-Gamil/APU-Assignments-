﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LECTURER
{
    public partial class CoachingRequest : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public CoachingRequest()
        {
            InitializeComponent();
        }

        private void CoachingRequest_Load(object sender, EventArgs e)
        {
            ArrayList request = new ArrayList(); // dynamic array (size is not allocated)

            request = AdditionalCoachingRequests.viewRequests();
            
            foreach (var item in request)
            {
                lstRequests.Items.Add(item);
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (lstRequests.SelectedItem != null)
            {
                string selectedRequest = lstRequests.SelectedItem.ToString();
                string student = selectedRequest.Split(' ')[0]; // Split(" ') splits the string into an array where ever ' ' is. [0] returns the first element. 
                string module = selectedRequest.Split(' ')[5]; // Split(" ') splits the string into an array where ever ' ' is. [7] returns the 6th element.
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
                con.Open();

                SqlCommand cmd = new SqlCommand("UPDATE CoachingRequest SET ApprovalStatus = 'Approved' WHERE Student = @Student AND Module = @Module", con);
                cmd.Parameters.AddWithValue("@Student", student);
                cmd.Parameters.AddWithValue("@Module", module);

                int i = cmd.ExecuteNonQuery(); // To check if registration was successfull. If one query is successfull then the rest are too.
                if (i != 0)
                {
                    MessageBox.Show("Approved Successfully!");
                }
                else
                    MessageBox.Show("Unable to Approve, Try Again!");
                con.Close();
            }
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            if (lstRequests.SelectedItem != null)
            {
                string selectedRequest = lstRequests.SelectedItem.ToString();
                string student = selectedRequest.Split(' ')[0]; // Split(" ') splits the string into an array where ever ' ' is. [0] returns the first element. 
                string module = selectedRequest.Split(' ')[5]; // Split(" ') splits the string into an array where ever ' ' is. [7] returns the 6th element.
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
                con.Open();

                SqlCommand cmd = new SqlCommand("UPDATE CoachingRequest SET ApprovalStatus = 'Rejected' WHERE Student = @Student AND Module = @Module", con);
                cmd.Parameters.AddWithValue("@Student", student);
                cmd.Parameters.AddWithValue("@Module", module);

                int i = cmd.ExecuteNonQuery(); // To check if registration was successfull. If one query is successfull then the rest are too.
                if (i != 0)
                {
                    MessageBox.Show("Rejected Successfully!");
                }
                else
                    MessageBox.Show("Unable to Reject, Try Again!");
                con.Close();
            }
        }
    }
}
