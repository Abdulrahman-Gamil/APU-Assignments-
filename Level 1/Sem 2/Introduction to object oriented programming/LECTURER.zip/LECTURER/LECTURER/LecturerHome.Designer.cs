﻿namespace LECTURER
{
    partial class LecturerHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLecturerHome = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnSubject = new System.Windows.Forms.Button();
            this.btnRequest = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.lblHelloUser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblLecturerHome
            // 
            this.lblLecturerHome.AutoSize = true;
            this.lblLecturerHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLecturerHome.Location = new System.Drawing.Point(178, 48);
            this.lblLecturerHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLecturerHome.Name = "lblLecturerHome";
            this.lblLecturerHome.Size = new System.Drawing.Size(242, 24);
            this.lblLecturerHome.TabIndex = 0;
            this.lblLecturerHome.Text = "LECTURER HOMEPAGE";
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRegister.Location = new System.Drawing.Point(112, 103);
            this.btnRegister.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(90, 32);
            this.btnRegister.TabIndex = 1;
            this.btnRegister.Text = "Enroll Students";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnSubject
            // 
            this.btnSubject.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSubject.Location = new System.Drawing.Point(398, 103);
            this.btnSubject.Margin = new System.Windows.Forms.Padding(2);
            this.btnSubject.Name = "btnSubject";
            this.btnSubject.Size = new System.Drawing.Size(90, 32);
            this.btnSubject.TabIndex = 2;
            this.btnSubject.Text = "Update Subject";
            this.btnSubject.UseVisualStyleBackColor = false;
            this.btnSubject.Click += new System.EventHandler(this.btnSubject_Click);
            // 
            // btnRequest
            // 
            this.btnRequest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRequest.Location = new System.Drawing.Point(112, 233);
            this.btnRequest.Margin = new System.Windows.Forms.Padding(2);
            this.btnRequest.Name = "btnRequest";
            this.btnRequest.Size = new System.Drawing.Size(111, 32);
            this.btnRequest.TabIndex = 3;
            this.btnRequest.Text = "Coaching Requests";
            this.btnRequest.UseVisualStyleBackColor = false;
            this.btnRequest.Click += new System.EventHandler(this.btnRequest_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDelete.Location = new System.Drawing.Point(398, 233);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 32);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "Delete Student";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnProfile.Location = new System.Drawing.Point(258, 167);
            this.btnProfile.Margin = new System.Windows.Forms.Padding(2);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(90, 32);
            this.btnProfile.TabIndex = 5;
            this.btnProfile.Text = "Update Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // lblHelloUser
            // 
            this.lblHelloUser.AutoSize = true;
            this.lblHelloUser.Location = new System.Drawing.Point(223, 85);
            this.lblHelloUser.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHelloUser.Name = "lblHelloUser";
            this.lblHelloUser.Size = new System.Drawing.Size(0, 13);
            this.lblHelloUser.TabIndex = 6;
            // 
            // LecturerHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(599, 415);
            this.Controls.Add(this.lblHelloUser);
            this.Controls.Add(this.btnProfile);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnRequest);
            this.Controls.Add(this.btnSubject);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.lblLecturerHome);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "LecturerHome";
            this.Text = "LecturerHome";
            this.Load += new System.EventHandler(this.LecturerHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLecturerHome;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnSubject;
        private System.Windows.Forms.Button btnRequest;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Label lblHelloUser;
    }
}