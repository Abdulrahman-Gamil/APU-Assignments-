﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace LECTURER
{
    public partial class LecturerHome : Form
    {
        public static string name; // globally assgined 

        public LecturerHome()
        {
            InitializeComponent();
        }

        public LecturerHome(string u) // u = username
        {
            InitializeComponent();
          
            name = Lecturer.GetLecturerName(u);
        }


        private void LecturerHome_Load(object sender, EventArgs e)
        {
            lblHelloUser.Text = "Hello, " + name + "! Welcome to your homepage!"; // username will be displayed when lecturer page loads
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterAndEnroll s = new RegisterAndEnroll();
            s.ShowDialog();
        }

        private void btnSubject_Click(object sender, EventArgs e)
        {
            UpdateSubject s = new UpdateSubject();
            s.ShowDialog();
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            CoachingRequest s = new CoachingRequest();
            s.ShowDialog();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteStudent s = new DeleteStudent();
            s.ShowDialog();
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            UpdateProfile s = new UpdateProfile(name);
            s.ShowDialog();
        }
    }
}
