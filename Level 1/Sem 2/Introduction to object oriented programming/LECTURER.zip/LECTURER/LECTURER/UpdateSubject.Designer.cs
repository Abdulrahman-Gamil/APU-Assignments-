﻿namespace LECTURER
{
    partial class UpdateSubject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUpdateSub = new System.Windows.Forms.Label();
            this.lblStuName = new System.Windows.Forms.Label();
            this.lblCurrSubject = new System.Windows.Forms.Label();
            this.txtStuName = new System.Windows.Forms.TextBox();
            this.btnUpdateSub = new System.Windows.Forms.Button();
            this.lblNewSubject = new System.Windows.Forms.Label();
            this.txtNewSub = new System.Windows.Forms.TextBox();
            this.lblCurrLevel = new System.Windows.Forms.Label();
            this.lblNewLevel = new System.Windows.Forms.Label();
            this.lblCurrent = new System.Windows.Forms.Label();
            this.cmbLevel = new System.Windows.Forms.ComboBox();
            this.lblCurrentSub = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblUpdateSub
            // 
            this.lblUpdateSub.AutoSize = true;
            this.lblUpdateSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUpdateSub.Location = new System.Drawing.Point(318, 27);
            this.lblUpdateSub.Name = "lblUpdateSub";
            this.lblUpdateSub.Size = new System.Drawing.Size(192, 29);
            this.lblUpdateSub.TabIndex = 0;
            this.lblUpdateSub.Text = "Update Subject";
            // 
            // lblStuName
            // 
            this.lblStuName.AutoSize = true;
            this.lblStuName.Location = new System.Drawing.Point(201, 108);
            this.lblStuName.Name = "lblStuName";
            this.lblStuName.Size = new System.Drawing.Size(95, 16);
            this.lblStuName.TabIndex = 1;
            this.lblStuName.Text = "Student Name:";
            // 
            // lblCurrSubject
            // 
            this.lblCurrSubject.AutoSize = true;
            this.lblCurrSubject.Location = new System.Drawing.Point(60, 201);
            this.lblCurrSubject.Name = "lblCurrSubject";
            this.lblCurrSubject.Size = new System.Drawing.Size(140, 16);
            this.lblCurrSubject.TabIndex = 2;
            this.lblCurrSubject.Text = "Current Subject Name:";
            // 
            // txtStuName
            // 
            this.txtStuName.Location = new System.Drawing.Point(332, 91);
            this.txtStuName.Name = "txtStuName";
            this.txtStuName.Size = new System.Drawing.Size(120, 22);
            this.txtStuName.TabIndex = 3;
            // 
            // btnUpdateSub
            // 
            this.btnUpdateSub.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUpdateSub.Location = new System.Drawing.Point(332, 335);
            this.btnUpdateSub.Name = "btnUpdateSub";
            this.btnUpdateSub.Size = new System.Drawing.Size(120, 40);
            this.btnUpdateSub.TabIndex = 5;
            this.btnUpdateSub.Text = "Update";
            this.btnUpdateSub.UseVisualStyleBackColor = false;
            this.btnUpdateSub.Click += new System.EventHandler(this.btnUpdateSub_Click);
            // 
            // lblNewSubject
            // 
            this.lblNewSubject.AutoSize = true;
            this.lblNewSubject.Location = new System.Drawing.Point(75, 260);
            this.lblNewSubject.Name = "lblNewSubject";
            this.lblNewSubject.Size = new System.Drawing.Size(125, 16);
            this.lblNewSubject.TabIndex = 6;
            this.lblNewSubject.Text = "New Subject Name:";
            // 
            // txtNewSub
            // 
            this.txtNewSub.Location = new System.Drawing.Point(206, 260);
            this.txtNewSub.Name = "txtNewSub";
            this.txtNewSub.Size = new System.Drawing.Size(120, 22);
            this.txtNewSub.TabIndex = 7;
            // 
            // lblCurrLevel
            // 
            this.lblCurrLevel.AutoSize = true;
            this.lblCurrLevel.Location = new System.Drawing.Point(482, 201);
            this.lblCurrLevel.Name = "lblCurrLevel";
            this.lblCurrLevel.Size = new System.Drawing.Size(88, 16);
            this.lblCurrLevel.TabIndex = 8;
            this.lblCurrLevel.Text = "Current Level:";
            // 
            // lblNewLevel
            // 
            this.lblNewLevel.AutoSize = true;
            this.lblNewLevel.Location = new System.Drawing.Point(497, 260);
            this.lblNewLevel.Name = "lblNewLevel";
            this.lblNewLevel.Size = new System.Drawing.Size(73, 16);
            this.lblNewLevel.TabIndex = 9;
            this.lblNewLevel.Text = "New Level:";
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrent.Location = new System.Drawing.Point(573, 201);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(0, 20);
            this.lblCurrent.TabIndex = 12;
            // 
            // cmbLevel
            // 
            this.cmbLevel.FormattingEnabled = true;
            this.cmbLevel.Items.AddRange(new object[] {
            "Beginner",
            "Intermediate",
            "Advance"});
            this.cmbLevel.Location = new System.Drawing.Point(576, 257);
            this.cmbLevel.Name = "cmbLevel";
            this.cmbLevel.Size = new System.Drawing.Size(120, 24);
            this.cmbLevel.TabIndex = 13;
            // 
            // lblCurrentSub
            // 
            this.lblCurrentSub.AutoSize = true;
            this.lblCurrentSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentSub.Location = new System.Drawing.Point(206, 201);
            this.lblCurrentSub.Name = "lblCurrentSub";
            this.lblCurrentSub.Size = new System.Drawing.Size(0, 20);
            this.lblCurrentSub.TabIndex = 14;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSearch.Location = new System.Drawing.Point(332, 142);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(120, 40);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // UpdateSubject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 511);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblCurrentSub);
            this.Controls.Add(this.cmbLevel);
            this.Controls.Add(this.lblCurrent);
            this.Controls.Add(this.lblNewLevel);
            this.Controls.Add(this.lblCurrLevel);
            this.Controls.Add(this.txtNewSub);
            this.Controls.Add(this.lblNewSubject);
            this.Controls.Add(this.btnUpdateSub);
            this.Controls.Add(this.txtStuName);
            this.Controls.Add(this.lblCurrSubject);
            this.Controls.Add(this.lblStuName);
            this.Controls.Add(this.lblUpdateSub);
            this.Name = "UpdateSubject";
            this.Text = "UpdateSubject";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUpdateSub;
        private System.Windows.Forms.Label lblStuName;
        private System.Windows.Forms.Label lblCurrSubject;
        private System.Windows.Forms.TextBox txtStuName;
        private System.Windows.Forms.Button btnUpdateSub;
        private System.Windows.Forms.Label lblNewSubject;
        private System.Windows.Forms.TextBox txtNewSub;
        private System.Windows.Forms.Label lblCurrLevel;
        private System.Windows.Forms.Label lblNewLevel;
        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.ComboBox cmbLevel;
        private System.Windows.Forms.Label lblCurrentSub;
        private System.Windows.Forms.Button btnSearch;
    }
}