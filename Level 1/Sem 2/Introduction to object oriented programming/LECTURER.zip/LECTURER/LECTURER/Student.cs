﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace LECTURER
{
    internal class Student
    {
        private string TPnumber;
        private string Name;
        private string Email;
        private string ContactNumber;
        private string Address;
        private string Level;
        private string Module;
        private string MonthOfEnrollment;
        private string CoachingStatus;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Module1 { get => Module; set => Module = value; }
        public string Level1 { get => Level; set => Level = value; }

        public Student(string TPnumber, string Name, string Email, string ContactNumber, string Address, string Level, string Module, string MonthOfEnrollment, string CoachingStatus = "In Progress")
        {
            this.TPnumber = TPnumber;
            this.Name = Name;
            this.Email = Email;
            this.ContactNumber = ContactNumber;
            this.Address = Address;
            this.Level = Level;
            this.Module = Module;
            this.MonthOfEnrollment = MonthOfEnrollment;
        }

        public Student(string Name, string Module, string Level)
        {
            this.Name = Name;
            this.Module = Module;
            this.Level = Level;
        }

        public Student(string Name)
        {
            this.Name = Name;
        }

        public Student()
        {
        }

        public string RegisterAndEnroll()
        {
            string status;
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Student(TPnumber, Name, Email, ContactNumber, Address, Level, Module, MonthOfEnrollment, CoachingStatus) values(@tp, @n, @e, @c, @a, @l, @m, @me, @cs)", con);
            cmd.Parameters.AddWithValue("@tp", TPnumber);
            cmd.Parameters.AddWithValue("@n", Name);
            cmd.Parameters.AddWithValue("@e", Email);
            cmd.Parameters.AddWithValue("@c", ContactNumber);
            cmd.Parameters.AddWithValue("@a", Address);
            cmd.Parameters.AddWithValue("@l", Level);
            cmd.Parameters.AddWithValue("@m", Module);
            cmd.Parameters.AddWithValue("@me", MonthOfEnrollment);
            cmd.Parameters.AddWithValue("@cs", "In Progress");

            SqlCommand cmd2 = new SqlCommand("select count(*) from Users where username = @tp", con);
            cmd2.Parameters.AddWithValue("@tp", TPnumber);
            int count = Convert.ToInt32(cmd2.ExecuteScalar());
            if (count == 0)
            {
                SqlCommand cmd3 = new SqlCommand("insert into Users(username, password, role) values(@tp,'5677AB','Student')", con); // Default password set
                cmd3.Parameters.AddWithValue("@tp", TPnumber);

                cmd3.ExecuteNonQuery(); //Record updated in User Table

                int i = cmd.ExecuteNonQuery(); // To check if registration was successfull. If one query is successfull then the rest are too.
                if (i != 0)
                {
                    status = "Registration Successfull!";
                }
                else
                    status = "Unable to Register";
                con.Close();
                return status;
            }
            else
                status = "Usename Already Exists!";
            con.Close();
            return status;
        }
        
        public static ArrayList GetCompletedStudents()
        {
            ArrayList cs = new ArrayList();
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT Name FROM Student WHERE CoachingStatus = 'Completed'", con);
            SqlDataReader rd = cmd.ExecuteReader();

            while (rd.Read())
            {
                string student = rd.GetString(0);
                cs.Add(student);
            }
            con.Close();
            return cs;
        }

        public static Student GetCurrentDetails(string stuName)
        {
            Student student = null; // this decalres a variable of student
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT Module, Level FROM Student WHERE Name = @Name", con);
            cmd.Parameters.AddWithValue("@Name", stuName);

            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.Read())
            {
                string module =  rd.GetString(0);
                string level =  rd.GetString(1);

                student = new Student(); // student object is created and assigned to student when rd.Read() returns true. 
                student.Module = module;
                student.Level = level;
                student.Name = stuName;
            }

            con.Close();
            return student;
        }

    }
}
