﻿namespace LECTURER
{
    partial class DeleteStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstComplete = new System.Windows.Forms.ListBox();
            this.lblDeleteStu = new System.Windows.Forms.Label();
            this.lblCoachingClasses = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstComplete
            // 
            this.lstComplete.FormattingEnabled = true;
            this.lstComplete.Location = new System.Drawing.Point(345, 85);
            this.lstComplete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lstComplete.Name = "lstComplete";
            this.lstComplete.Size = new System.Drawing.Size(139, 121);
            this.lstComplete.TabIndex = 0;
            // 
            // lblDeleteStu
            // 
            this.lblDeleteStu.AutoSize = true;
            this.lblDeleteStu.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDeleteStu.Location = new System.Drawing.Point(242, 7);
            this.lblDeleteStu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDeleteStu.Name = "lblDeleteStu";
            this.lblDeleteStu.Size = new System.Drawing.Size(147, 24);
            this.lblDeleteStu.TabIndex = 1;
            this.lblDeleteStu.Text = "Delete Student";
            // 
            // lblCoachingClasses
            // 
            this.lblCoachingClasses.AutoSize = true;
            this.lblCoachingClasses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoachingClasses.Location = new System.Drawing.Point(9, 85);
            this.lblCoachingClasses.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCoachingClasses.Name = "lblCoachingClasses";
            this.lblCoachingClasses.Size = new System.Drawing.Size(309, 16);
            this.lblCoachingClasses.TabIndex = 2;
            this.lblCoachingClasses.Text = "Students with Completed Coaching Classes:";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDelete.Location = new System.Drawing.Point(262, 262);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(90, 32);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // DeleteStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(599, 415);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblCoachingClasses);
            this.Controls.Add(this.lblDeleteStu);
            this.Controls.Add(this.lstComplete);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "DeleteStudent";
            this.Text = "DeleteStudent";
            this.Load += new System.EventHandler(this.DeleteStudent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstComplete;
        private System.Windows.Forms.Label lblDeleteStu;
        private System.Windows.Forms.Label lblCoachingClasses;
        private System.Windows.Forms.Button btnDelete;
    }
}