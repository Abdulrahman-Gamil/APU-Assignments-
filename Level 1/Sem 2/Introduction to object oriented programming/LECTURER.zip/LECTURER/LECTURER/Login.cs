﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LECTURER
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string stat; // will hold the status of the login
            User obj1 = new User(txtUsername.Text,txtPassword.Text); // uses constuctor to store the values in textbox
            stat = obj1.login(txtUsername.Text); // calls login method through "obj1" and stores retun value in "stat"
            if(stat != null) // if state != null meaning login failed, so "Incorrect username/password" displayed to user
            {
                MessageBox.Show(stat);
            }
            txtUsername.Text = String.Empty; // Textbox reset
            txtPassword.Text = String.Empty; // Textbox reset
            // If stat = null it just resets the textboxes
        }
    }
}
