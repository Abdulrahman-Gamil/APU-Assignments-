﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LECTURER
{
    internal class User
    {
        private string username;
        private string password;
        private string role;

        public User(string uname, string pass)
        {
            username = uname;
            password = pass;
        }

        public User(string uname, string pass, string rol)
        {
            username = uname;
            password = pass;
            role = rol;
        }

        public string login(string un) //method recevives username entered in the textbox
        {
            string status = null; // to store status of login
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();

            //SqlCommand cmd = new SqlCommand("select count(*) from users where username = '" + username + "' and password = '" + password + "'", con);
            SqlCommand cmd = new SqlCommand("select count(*) from users where username = @a and password = @b", con); // modified version
            cmd.Parameters.AddWithValue("username", username);
            cmd.Parameters.AddWithValue("@a", username); // @a = username
            cmd.Parameters.AddWithValue("@b", password); // @b = password

            int count = Convert.ToInt32(cmd.ExecuteScalar());

            if (count > 0) // login successfull now find userRole
            {
                SqlCommand cmd2 = new SqlCommand("select role from Users where username = @a and password = @b", con); //cmd2 used cuz can't use same obj name in the same method 
                cmd2.Parameters.AddWithValue("@a", username);
                cmd2.Parameters.AddWithValue("@b", password);

                string userRole = cmd2.ExecuteScalar().ToString(); // string userRole = Lecturer. Redirects to the userRoles form
                /*
                if (userRole == "admin")
                {
                    AdminHome a = new AdminHome(un);
                    a.ShowDialog();
                }
                else if (userRole == "trainer")
                {
                    TrainerHome s = new TrainerHome(un);
                    s.ShowDialog();
                }
                */
                if (userRole == "Lecturer")
                {
                    LecturerHome s = new LecturerHome(un); //passing username to the constuctor of the lecturehome form
                    s.ShowDialog();
                }
                /*
                else if (userRole == "student")
                {
                StudentHome s = new StudentHome(un);
                s.ShowDialog();
                }*/
            }
            else
                status = "Incorrect username/password";
            con.Close();

            return status; // status = "Incorrect username/password" if login failed and status = "NULL" if login successfull
        }
    }
}