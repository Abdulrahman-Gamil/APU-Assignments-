﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LECTURER
{
    public partial class UpdateSubject : Form
    {
        public UpdateSubject()
        {
            InitializeComponent();
        }

        private void btnUpdateSub_Click(object sender, EventArgs e)
        {
            /*
            Student obj1 = new Student(txtStuName.Text); // create a new Student object with the entered name

            string result = obj1.UpdateSubject(txtSubject.Text); // call the UpdateSubject method on the student object, passing the entered subject name

            MessageBox.Show(result);
            */

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();

            SqlCommand cmd = new SqlCommand("UPDATE Student SET Module = @Module, Level = @Level WHERE Name = @Name", con);

            cmd.Parameters.AddWithValue("@Module", txtNewSub.Text);
            cmd.Parameters.AddWithValue("@Level", cmbLevel.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@Name", txtStuName.Text);

            int i = cmd.ExecuteNonQuery();

            if (i != 0)
            {
                MessageBox.Show("Updated Successfully!");
            }
            else
            {
                MessageBox.Show("Unable to Update, Try Again!");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student = Student.GetCurrentDetails(txtStuName.Text);
            if (student != null)
            {
                lblCurrentSub.Text = student.Module1;
                lblCurrent.Text = student.Level1;
            }
        }

       
    }
}
