﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LECTURER
{
    public partial class RegisterAndEnroll : Form
    {
        public RegisterAndEnroll()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Student obj1 = new Student(txtTP.Text, txtName.Text, txtEmail.Text, txtContact.Text, txtAddress.Text, txtLevel.Text, txtModule.Text, txtMonthE.Text);
            MessageBox.Show(obj1.RegisterAndEnroll()); // shows if registration is successfull or not
        }
    }

}
