﻿namespace LECTURER
{
    partial class RegisterAndEnroll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnroll = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblTP = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblLevel = new System.Windows.Forms.Label();
            this.lblModule = new System.Windows.Forms.Label();
            this.lblMonthE = new System.Windows.Forms.Label();
            this.txtTP = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtLevel = new System.Windows.Forms.TextBox();
            this.txtMonthE = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblTPn = new System.Windows.Forms.Label();
            this.txtModule = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblEnroll
            // 
            this.lblEnroll.AutoSize = true;
            this.lblEnroll.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnroll.Location = new System.Drawing.Point(232, 21);
            this.lblEnroll.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEnroll.Name = "lblEnroll";
            this.lblEnroll.Size = new System.Drawing.Size(152, 24);
            this.lblEnroll.TabIndex = 0;
            this.lblEnroll.Text = "Enroll Students";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(139, 104);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name:";
            // 
            // lblTP
            // 
            this.lblTP.AutoSize = true;
            this.lblTP.Location = new System.Drawing.Point(1107, 480);
            this.lblTP.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTP.Name = "lblTP";
            this.lblTP.Size = new System.Drawing.Size(64, 13);
            this.lblTP.TabIndex = 2;
            this.lblTP.Text = "TP Number:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(139, 135);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 3;
            this.lblEmail.Text = "Email:";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(139, 164);
            this.lblContact.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(87, 13);
            this.lblContact.TabIndex = 4;
            this.lblContact.Text = "Contact Number:";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(139, 192);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(48, 13);
            this.lblAddress.TabIndex = 5;
            this.lblAddress.Text = "Address:";
            // 
            // lblLevel
            // 
            this.lblLevel.AutoSize = true;
            this.lblLevel.Location = new System.Drawing.Point(139, 222);
            this.lblLevel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLevel.Name = "lblLevel";
            this.lblLevel.Size = new System.Drawing.Size(36, 13);
            this.lblLevel.TabIndex = 6;
            this.lblLevel.Text = "Level:";
            // 
            // lblModule
            // 
            this.lblModule.AutoSize = true;
            this.lblModule.Location = new System.Drawing.Point(139, 254);
            this.lblModule.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblModule.Name = "lblModule";
            this.lblModule.Size = new System.Drawing.Size(45, 13);
            this.lblModule.TabIndex = 7;
            this.lblModule.Text = "Module:";
            // 
            // lblMonthE
            // 
            this.lblMonthE.AutoSize = true;
            this.lblMonthE.Location = new System.Drawing.Point(139, 283);
            this.lblMonthE.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMonthE.Name = "lblMonthE";
            this.lblMonthE.Size = new System.Drawing.Size(102, 13);
            this.lblMonthE.TabIndex = 8;
            this.lblMonthE.Text = "Month of Enrolment:";
            // 
            // txtTP
            // 
            this.txtTP.Location = new System.Drawing.Point(246, 75);
            this.txtTP.Margin = new System.Windows.Forms.Padding(2);
            this.txtTP.Name = "txtTP";
            this.txtTP.Size = new System.Drawing.Size(91, 20);
            this.txtTP.TabIndex = 9;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(246, 104);
            this.txtName.Margin = new System.Windows.Forms.Padding(2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(91, 20);
            this.txtName.TabIndex = 10;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(246, 135);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(91, 20);
            this.txtEmail.TabIndex = 11;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(246, 164);
            this.txtContact.Margin = new System.Windows.Forms.Padding(2);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(91, 20);
            this.txtContact.TabIndex = 12;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(246, 192);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(91, 20);
            this.txtAddress.TabIndex = 13;
            // 
            // txtLevel
            // 
            this.txtLevel.Location = new System.Drawing.Point(246, 222);
            this.txtLevel.Margin = new System.Windows.Forms.Padding(2);
            this.txtLevel.Name = "txtLevel";
            this.txtLevel.Size = new System.Drawing.Size(91, 20);
            this.txtLevel.TabIndex = 14;
            // 
            // txtMonthE
            // 
            this.txtMonthE.Location = new System.Drawing.Point(246, 283);
            this.txtMonthE.Margin = new System.Windows.Forms.Padding(2);
            this.txtMonthE.Name = "txtMonthE";
            this.txtMonthE.Size = new System.Drawing.Size(91, 20);
            this.txtMonthE.TabIndex = 16;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRegister.Location = new System.Drawing.Point(246, 334);
            this.btnRegister.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(91, 32);
            this.btnRegister.TabIndex = 17;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // lblTPn
            // 
            this.lblTPn.AutoSize = true;
            this.lblTPn.Location = new System.Drawing.Point(139, 75);
            this.lblTPn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTPn.Name = "lblTPn";
            this.lblTPn.Size = new System.Drawing.Size(64, 13);
            this.lblTPn.TabIndex = 18;
            this.lblTPn.Text = "TP Number:";
            // 
            // txtModule
            // 
            this.txtModule.Location = new System.Drawing.Point(246, 251);
            this.txtModule.Name = "txtModule";
            this.txtModule.Size = new System.Drawing.Size(91, 20);
            this.txtModule.TabIndex = 19;
            // 
            // RegisterAndEnroll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(599, 415);
            this.Controls.Add(this.txtModule);
            this.Controls.Add(this.lblTPn);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.txtMonthE);
            this.Controls.Add(this.txtLevel);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtTP);
            this.Controls.Add(this.lblMonthE);
            this.Controls.Add(this.lblModule);
            this.Controls.Add(this.lblLevel);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblTP);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblEnroll);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "RegisterAndEnroll";
            this.Text = "RegisterAndEnroll";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEnroll;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblTP;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblLevel;
        private System.Windows.Forms.Label lblModule;
        private System.Windows.Forms.Label lblMonthE;
        private System.Windows.Forms.TextBox txtTP;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtLevel;
        private System.Windows.Forms.TextBox txtMonthE;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label lblTPn;
        private System.Windows.Forms.TextBox txtModule;
    }
}