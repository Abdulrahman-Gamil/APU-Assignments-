﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LECTURER
{
    internal class Lecturer
    {
        private string Username;
        private string Name;
        private string Email;
        private string ContactNumber;
        private string Address;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        public string Name1 { get => Name; set => Name = value; } // Can not be Name and name, cuz pivate string is Name, so has to be Name1
        public string Email1 { get => Email; set => Email = value; }
        public string ContactNumber1 { get => ContactNumber; set => ContactNumber = value; }
        public string Address1 { get => Address; set => Address = value; }

        public Lecturer() { }

        public Lecturer(string Username, string Name, string Email, string ContactNumber, string Address)
        {
            this.Username = Username;
            this.Name = Name;
            this.Email = Email;
            this.ContactNumber = ContactNumber;
            this.Address = Address;
        }

        public Lecturer(string n)
        {
            Name = n;
        }

        public static void viewProfile(Lecturer o1)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Lecturer where Name = @name", con);
            cmd.Parameters.AddWithValue("@name", o1.Name);
            SqlDataReader rd = cmd.ExecuteReader();

            while(rd.Read())
            {
                o1.Email = rd.GetString (3);
                o1.ContactNumber = rd.GetString (4);
                o1.Address = rd.GetString (5);
            }
            con.Close();
        }

        public static string GetLecturerName(string username)
        {
            string n = null;
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT Name FROM Lecturer WHERE username = @username", con);
            cmd.Parameters.AddWithValue("@username", username);

            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                n = rd.GetString(0); // get the first column of the result
            }
  
            con.Close();
            return n;
        }

        public string profileChanges(string n, string e, string c, string a)
        {
            string status;
            con.Open();

            Name = n;
            Email = e;
            ContactNumber = c;
            Address = a;

            SqlCommand cmd = new SqlCommand("UPDATE Lecturer set Name = @n, Email = @e, ContactNumber = @c, Address = @a", con);
            cmd.Parameters.AddWithValue("@n", Name);
            cmd.Parameters.AddWithValue("@e", Email);
            cmd.Parameters.AddWithValue("@c", ContactNumber);
            cmd.Parameters.AddWithValue("@a", Address);

            int i = cmd.ExecuteNonQuery(); // To check if update was successfull. If one query is successfull then the rest are too.
            if (i != 0)
            {
                status = "Updated Successfull!";
            }
            else
                status = "Unable to Update";
            con.Close();
            return status;
        }
        


    }
}
