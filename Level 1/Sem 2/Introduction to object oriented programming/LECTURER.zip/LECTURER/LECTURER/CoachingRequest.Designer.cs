﻿namespace LECTURER
{
    partial class CoachingRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstRequests = new System.Windows.Forms.ListBox();
            this.btnApprove = new System.Windows.Forms.Button();
            this.lblAdditionalRequests = new System.Windows.Forms.Label();
            this.lblRequests = new System.Windows.Forms.Label();
            this.btnReject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstRequests
            // 
            this.lstRequests.FormattingEnabled = true;
            this.lstRequests.Location = new System.Drawing.Point(159, 100);
            this.lstRequests.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lstRequests.Name = "lstRequests";
            this.lstRequests.Size = new System.Drawing.Size(365, 95);
            this.lstRequests.TabIndex = 0;
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnApprove.Location = new System.Drawing.Point(127, 293);
            this.btnApprove.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(90, 32);
            this.btnApprove.TabIndex = 1;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // lblAdditionalRequests
            // 
            this.lblAdditionalRequests.AutoSize = true;
            this.lblAdditionalRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdditionalRequests.Location = new System.Drawing.Point(182, 30);
            this.lblAdditionalRequests.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAdditionalRequests.Name = "lblAdditionalRequests";
            this.lblAdditionalRequests.Size = new System.Drawing.Size(291, 24);
            this.lblAdditionalRequests.TabIndex = 3;
            this.lblAdditionalRequests.Text = "Additional Coaching Requests";
            // 
            // lblRequests
            // 
            this.lblRequests.AutoSize = true;
            this.lblRequests.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRequests.Location = new System.Drawing.Point(50, 100);
            this.lblRequests.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRequests.Name = "lblRequests";
            this.lblRequests.Size = new System.Drawing.Size(77, 16);
            this.lblRequests.TabIndex = 4;
            this.lblRequests.Text = "Requests:";
            // 
            // btnReject
            // 
            this.btnReject.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReject.Location = new System.Drawing.Point(360, 293);
            this.btnReject.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(90, 32);
            this.btnReject.TabIndex = 5;
            this.btnReject.Text = "Reject";
            this.btnReject.UseVisualStyleBackColor = false;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // CoachingRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(599, 415);
            this.Controls.Add(this.btnReject);
            this.Controls.Add(this.lblRequests);
            this.Controls.Add(this.lblAdditionalRequests);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.lstRequests);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CoachingRequest";
            this.Text = "CoachingRequest";
            this.Load += new System.EventHandler(this.CoachingRequest_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstRequests;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Label lblAdditionalRequests;
        private System.Windows.Forms.Label lblRequests;
        private System.Windows.Forms.Button btnReject;
    }
}