﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;
using System.Xml.Linq;

namespace LECTURER
{
    public partial class UpdateProfile : Form
    {
        public static string name; // globally assgined 

        public UpdateProfile()
        {
            InitializeComponent();
        }

        public UpdateProfile(string n)
        {
            InitializeComponent();
            name = n; 
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Lecturer obj1 = new Lecturer(name);
            MessageBox.Show(obj1.profileChanges(txtName.Text, txtEmail.Text, txtContact.Text, txtAddress.Text));
        }

        private void UpdateProfile_Load(object sender, EventArgs e)
        {
            Lecturer obj1 = new Lecturer(name);

            Lecturer.viewProfile(obj1);

            txtName.Text = obj1.Name1;
            txtEmail.Text = obj1.Email1;
            txtContact.Text = obj1.ContactNumber1;
            txtAddress.Text = obj1.Address1;

        }
    }
}
