﻿using System;
using System.Windows.Forms;

namespace Student
{
    public partial class Profile : Form
    {
        public static string name;
        public Profile(string n)
        {
            InitializeComponent();
            name = n;
            this.CenterToScreen();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            MessageBox.Show(student.UpdateProfile(txtName.Text, txtEmail.Text, txtContact.Text, txtAddress.Text, name));

        }

        private void Profile_Load(object sender, EventArgs e)
        {

        }


    }
}
