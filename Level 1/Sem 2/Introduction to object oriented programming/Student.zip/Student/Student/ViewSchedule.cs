﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Student
{
    public partial class ViewSchedule : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        public ViewSchedule()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void ViewSchedule_Load(object sender, EventArgs e)
        {
            // Creating an ArrayList to store schedule information
            ArrayList sch = new ArrayList();

            // Calling the static method ViewAll() from the Student class to retrieve schedule information
            sch = Student.ViewAll();


            ArrayList nm = new ArrayList();
            con.Open();

            // Creating a SQL command to retrieve schedule data
            SqlCommand cmd = new SqlCommand("select Class, Time, Day from Schedule", con);
            SqlDataReader rd = cmd.ExecuteReader();

            // Looping through the result and adding schedule items to the ListBox control
            while (rd.Read())
            {
                listBox1.Items.Add(rd.GetString(0) + "\t \t" + rd.GetString(1) + "\t" + rd.GetString(2));
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
