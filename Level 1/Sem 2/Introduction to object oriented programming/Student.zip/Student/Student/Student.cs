﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;

namespace Student
{
    internal class Student
    {
        // Declaring private fields for student information
        private string username;
        private string currName;
        private string password;
        private string name;
        private string email;
        private string contNum;
        private string address;

        // Creating a static SqlConnection object using a connection string from configuration
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        // Parameterized constructor to initialize the username and password
        public Student(string u, string p)
        {
            username = u;
            password = p;
        }

        // Default constructor
        public Student() { }

        // Method for implementing student login
        public string Login(string un)//un = Mohammed
        {
            currName = un;
            string status = null;

            // Opening a connection to the database
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
            con.Open();


            // Creating a SQL command to check username and password in the database
            SqlCommand cmd = new SqlCommand("select count(*) from users where username=@a and password =@b", con);
            cmd.Parameters.AddWithValue("@a", username);//@a ==> Mohammed
            cmd.Parameters.AddWithValue("@b", password);//@b ==> abc123

            // Executing the command and getting the count of matching rows
            int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (count > 0) // if login success
            {
                // Checking the user role
                SqlCommand cmd2 = new SqlCommand("select role from users where username =@a and password =@b", con);
                cmd2.Parameters.AddWithValue("@a", username);//@a ==> Mohammed
                cmd2.Parameters.AddWithValue("@b", password);//@b ==> abc123


                string userRole = cmd2.ExecuteScalar().ToString();

                if (userRole == "student")
                {
                    // Creating a new instance of the HomePage class and displaying it
                    HomePage s = new HomePage(un);//un Mohammed
                    s.Show();
                }

            }
            else
            {
                status = "Incorect username/password";
            }
            // Closing the connection
            con.Close();

            return status;

        }


        // Method to view all schedule information
        public static ArrayList ViewAll()
        {
            ArrayList nm = new ArrayList();
            con.Open();

            // Creating a SQL command to retrieve schedule data
            SqlCommand cmd = new SqlCommand("select Class, Time, Day from Schedule", con);
            SqlDataReader rd = cmd.ExecuteReader();

            // Looping through the result and adding class names to the ArrayList
            while (rd.Read())
            {
                nm.Add(rd.GetString(0));
            }

            // Closing the connection
            con.Close();
            return nm;



        }
        //public static ArrayList ViewPay()
        //{
        //    ArrayList pm = new ArrayList();
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("select  Name, Module, Amount, Status from Payment", con);
        //    SqlDataReader rd = cmd.ExecuteReader();
        //    while (rd.Read())
        //    {
        //        pm.Add(rd.GetString(0));
        //    }
        //    con.Close();
        //    return pm;

        //}

        // Method to update student profile
        public string UpdateProfile(string name, string email, string contNum, string address, string currName)
        {
            string result;
            bool status, status2;
            con.Open();

            // Assigning the provided values to the corresponding fields
            this.name = name;
            this.email = email;
            this.contNum = contNum;
            this.address = address;
            this.currName = currName;

            // Creating a SQL command to update the student profile
            SqlCommand cmd = new SqlCommand("UPDATE Student SET Email = @em, Name = @na, Address = @add, ContactNumber = @cn Where Name = @cur", con);


            // Adding parameters to the command
            cmd.Parameters.AddWithValue("@na", this.name);
            cmd.Parameters.AddWithValue("@em", this.email);
            cmd.Parameters.AddWithValue("@cn", this.contNum);
            cmd.Parameters.AddWithValue("@add", this.address);
            cmd.Parameters.AddWithValue("@cur", this.currName);

            // Executing the command and getting the number of affected rows
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = true;
            else
                status = false;

            // Closing the connection
            con.Close();



            con.Open();

            // Updating the username in the Users table
            cmd.CommandText = "UPDATE Users SET username = @na Where username = @cur";


            //cmd.CommandText = "UPDATE Student SET Email = @em, Name = @na, Address = @add, ContactNumber = @cn Where Name = @cur";
            int j = cmd.ExecuteNonQuery();
            if (j != 0)
                status2 = true;
            else
                status2 = false;

            // Closing the connection
            con.Close();

            if (status && status2)
            {
                result = "Updated Succesfully!";
            }
            else
            {
                result = "Update Failed!";
            }
            return result;
        }
    }
}


