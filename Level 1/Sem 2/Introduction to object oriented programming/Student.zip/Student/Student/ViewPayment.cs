﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Student
{
    public partial class ViewPayment : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());
        string username;
        public ViewPayment()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void ViewPayment_Load(object sender, EventArgs e)
        {
            // Creating an ArrayList to store payment information
            ArrayList pm = new ArrayList();

            // Creating an instance of the HomePage form to get the username
            HomePage home = new HomePage();
            username = home.Name;

            // Calling the static method ViewAll() from the Student class to retrieve payment information
            pm = Student.ViewAll();

            ArrayList nm = new ArrayList();
            con.Open();

            // Creating a SQL command to retrieve payment data
            SqlCommand cmd = new SqlCommand("SELECT Name, Module, Amount, Status FROM Payment WHERE Name = @un and Status = 'unpaid'", con);
            cmd.Parameters.AddWithValue("@un", username);

            SqlDataReader rd = cmd.ExecuteReader();

            // Looping through the result and adding payment items to the ListView control
            while (rd.Read())
            {
                lstView.Items.Add(rd.GetString(0) + "\t \t" + rd.GetString(1) + "\t" + rd.GetInt32(2).ToString() + "\t" + rd.GetString(3));

            }
            if (lstView.Items.Count == 0)
            {
                lblEmpty.Text = "You don't have any pending payments!";
            }
            con.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnBuy_Click(object sender, EventArgs e)
        {
            // Creating an instance of the HomePage form to get the username
            HomePage home = new HomePage(username);
            username = home.Name;

            // Displaying a confirmation message box
            if (MessageBox.Show("Are you Sure you want to confirm the payment?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string status;
                con.Open();

                // Creating a SQL command to update the payment status to "paid"
                SqlCommand cmd = new SqlCommand("UPDATE Payment SET Status = 'paid' Where Name = @un and Status = 'unpaid'", con);

                // Adding a username parameter to the command
                cmd.Parameters.AddWithValue("@un", username);

                // Executing the command and getting the number of affected rows
                int i = cmd.ExecuteNonQuery();
                if (i != 0)
                    status = "Payment Confiremed";
                else
                    status = "Paymend declined!";
                con.Close();

                // Showing the HomePage form and closing the ViewPayment form
                home.Show();
                this.Close();
            }

        }
    }
}
