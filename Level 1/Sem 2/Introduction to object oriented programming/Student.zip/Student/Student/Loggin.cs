﻿using System;
using System.Windows.Forms;

namespace Student
{
    public partial class Loggin : Form
    {
        // private const string username = "seraj";
        //private const string password = "123";
        private string name;
        public string Name { get => name; set => name = txtUsername.Text; }

        public Loggin()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string stat;
            Student obj1 = new Student(txtUsername.Text, txtPassword.Text);
            stat = obj1.Login(txtUsername.Text);

            if (stat != null)
            {
                MessageBox.Show(stat);
            }

            txtUsername.Text = String.Empty;
            txtPassword.Text = String.Empty;

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
                txtPassword.UseSystemPasswordChar = true;
        }
    }
}
