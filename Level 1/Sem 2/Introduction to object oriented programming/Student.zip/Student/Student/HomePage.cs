﻿using System;
using System.Windows.Forms;

namespace Student
{
    public partial class HomePage : Form
    {
        private static string name;
        public string Name { get => name; set => name = value; }

        public HomePage(string un)
        {
            InitializeComponent();
            name = un;
            this.CenterToScreen();
        }
        public HomePage() { }

        private void btnViewScheduale_Click(object sender, EventArgs e)
        {
            ViewSchedule view = new ViewSchedule();
            view.Show();
        }

        private void btnRequests_Click(object sender, EventArgs e)
        {
            Request req = new Request(name);
            req.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Profile prf = new Profile(name);
            prf.Show();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            ViewPayment vp = new ViewPayment();
            vp.Show();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            lblStudentID.Text = "Hello " + name;
        }
    }
}
