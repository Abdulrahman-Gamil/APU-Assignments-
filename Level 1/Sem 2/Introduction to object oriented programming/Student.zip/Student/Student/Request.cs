﻿using System;
using System.Windows.Forms;

namespace Student
{
    public partial class Request : Form
    {
        string username;
        string moduleName;
        public Request(string username)
        {
            InitializeComponent();
            this.CenterToScreen();
            this.username = username;
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            moduleName = txtModuleName.Text;
            RequestCoaching reqCoaching = new RequestCoaching();
            MessageBox.Show(reqCoaching.UpdateRequest(username, moduleName, "Pending"));
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            moduleName = txtDelete.Text;
            RequestCoaching reqCoaching = new RequestCoaching();
            MessageBox.Show(reqCoaching.deleteRequest(username, moduleName));
        }
    }
}
