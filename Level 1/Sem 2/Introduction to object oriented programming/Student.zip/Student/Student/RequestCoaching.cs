﻿using System.Configuration;
using System.Data.SqlClient;

namespace Student
{
    internal class RequestCoaching
    {
        // Creating an SqlConnection object using a connection string from configuration
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myCS"].ToString());

        // Default constructor
        public RequestCoaching() { }

        // Method to update a coaching request
        public string UpdateRequest(string studentName, string moduleName, string approvalStatus)
        {
            string status;
            con.Open();

            // Creating a SQL command to insert a new coaching request
            SqlCommand cmd = new SqlCommand("INSERT INTO CoachingRequest(Student, Module, ApprovalStatus) VALUES(@un, @mn, @as)", con);

            // Adding parameters to the command
            cmd.Parameters.AddWithValue("@un", studentName);
            cmd.Parameters.AddWithValue("@mn", moduleName);
            cmd.Parameters.AddWithValue("@as", approvalStatus);

            // Executing the command and getting the number of affected rows
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Updated Successfully!";
            else
                status = "Update failed";

            // Closing the connection
            con.Close();

            return status;
        }

        // delete a coaching request
        public string deleteRequest(string studentName, string moduleName)
        {
            string status;
            con.Open();

            // Creating a SQL command to delete a coaching request
            SqlCommand cmd = new SqlCommand("DELETE FROM CoachingRequest where Student = @un and Module = @mn", con);

            // Adding parameters to the command
            cmd.Parameters.AddWithValue("@un", studentName);
            cmd.Parameters.AddWithValue("@mn", moduleName);

            // Executing the command and getting the number of affected rows
            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Delete Successfully!";
            else
                status = "Update failed";

            // Closing the connection
            con.Close();

            return status;
        }
    }
}
