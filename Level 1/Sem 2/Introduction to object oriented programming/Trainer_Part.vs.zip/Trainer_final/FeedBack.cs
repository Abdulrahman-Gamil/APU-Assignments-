﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Trainer_final
{
    public partial class FeedBack : Form
    {
        private string username;

        public FeedBack(string username)
        {
            InitializeComponent();
            this.username= username;
            
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
           
            Main_Page mp = new Main_Page(username);
            mp.Show();
            this.Hide();
        }

        private void btn_Send_Click(object sender, EventArgs e)
        {
            string feedback = txtBox_Feedback.Text;  // Get the feedback from the textbox
            string username = this.username;  // Retrieve the username

            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string status;
                conn.Open();

                using (SqlCommand cmd = new SqlCommand("INSERT INTO Feedback (username, Feedback_Message) VALUES (@username, @feedback)", conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);  // Add the username parameter
                    cmd.Parameters.AddWithValue("@feedback", feedback);  // Add the feedback parameter

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        status = "Feedback sent successfully";
                    else
                        status = "Failed to send feedback";
                }

                conn.Close();

                MessageBox.Show(status);  // Show the status message
            }

            // Clear the textbox
            txtBox_Feedback.Text = string.Empty;

        }

        private void FeedBack_Load(object sender, EventArgs e)
        {

        }
    }
}
