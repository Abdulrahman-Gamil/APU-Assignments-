﻿namespace Trainer_final
{
    partial class Main_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Update_My_Profile = new System.Windows.Forms.Button();
            this.btn_Send_Feedback = new System.Windows.Forms.Button();
            this.btn_Students_information = new System.Windows.Forms.Button();
            this.btn_Class_D = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.lbl_Hello = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Update_My_Profile
            // 
            this.btn_Update_My_Profile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Update_My_Profile.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update_My_Profile.Location = new System.Drawing.Point(254, 263);
            this.btn_Update_My_Profile.Name = "btn_Update_My_Profile";
            this.btn_Update_My_Profile.Size = new System.Drawing.Size(116, 71);
            this.btn_Update_My_Profile.TabIndex = 33;
            this.btn_Update_My_Profile.Text = "Update My Profile.";
            this.btn_Update_My_Profile.UseVisualStyleBackColor = false;
            this.btn_Update_My_Profile.Click += new System.EventHandler(this.btn_Update_My_Profile_Click);
            // 
            // btn_Send_Feedback
            // 
            this.btn_Send_Feedback.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Send_Feedback.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Send_Feedback.Location = new System.Drawing.Point(388, 263);
            this.btn_Send_Feedback.Name = "btn_Send_Feedback";
            this.btn_Send_Feedback.Size = new System.Drawing.Size(116, 71);
            this.btn_Send_Feedback.TabIndex = 32;
            this.btn_Send_Feedback.Text = "Sending Feedback.";
            this.btn_Send_Feedback.UseVisualStyleBackColor = false;
            this.btn_Send_Feedback.Click += new System.EventHandler(this.btn_Send_Feedback_Click);
            // 
            // btn_Students_information
            // 
            this.btn_Students_information.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Students_information.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Students_information.Location = new System.Drawing.Point(254, 190);
            this.btn_Students_information.Name = "btn_Students_information";
            this.btn_Students_information.Size = new System.Drawing.Size(116, 68);
            this.btn_Students_information.TabIndex = 31;
            this.btn_Students_information.Text = "Students Information.";
            this.btn_Students_information.UseVisualStyleBackColor = false;
            this.btn_Students_information.Click += new System.EventHandler(this.btn_Students_information_Click);
            // 
            // btn_Class_D
            // 
            this.btn_Class_D.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Class_D.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Class_D.Location = new System.Drawing.Point(388, 190);
            this.btn_Class_D.Name = "btn_Class_D";
            this.btn_Class_D.Size = new System.Drawing.Size(114, 62);
            this.btn_Class_D.TabIndex = 30;
            this.btn_Class_D.Text = "Class Details.";
            this.btn_Class_D.UseVisualStyleBackColor = false;
            this.btn_Class_D.Click += new System.EventHandler(this.btn_Update_Class_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Logout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Logout.Location = new System.Drawing.Point(655, 387);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(96, 37);
            this.btn_Logout.TabIndex = 29;
            this.btn_Logout.Text = "Logout.";
            this.btn_Logout.UseVisualStyleBackColor = false;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // lbl_Hello
            // 
            this.lbl_Hello.AutoSize = true;
            this.lbl_Hello.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_Hello.Font = new System.Drawing.Font("Viner Hand ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hello.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_Hello.Location = new System.Drawing.Point(261, 67);
            this.lbl_Hello.Name = "lbl_Hello";
            this.lbl_Hello.Size = new System.Drawing.Size(230, 48);
            this.lbl_Hello.TabIndex = 26;
            this.lbl_Hello.Text = "Hello Trainer.";
            this.lbl_Hello.Click += new System.EventHandler(this.lbl_Hello_Click);
            // 
            // Main_Page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trainer_final.Properties.Resources.WhatsApp_Image_2023_06_04_at_17_51_59;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(768, 432);
            this.Controls.Add(this.btn_Update_My_Profile);
            this.Controls.Add(this.btn_Send_Feedback);
            this.Controls.Add(this.btn_Students_information);
            this.Controls.Add(this.btn_Class_D);
            this.Controls.Add(this.btn_Logout);
            this.Controls.Add(this.lbl_Hello);
            this.Name = "Main_Page";
            this.Text = "Main_Page";
            this.Load += new System.EventHandler(this.Main_Page_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Update_My_Profile;
        private System.Windows.Forms.Button btn_Send_Feedback;
        private System.Windows.Forms.Button btn_Students_information;
        private System.Windows.Forms.Button btn_Class_D;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Label lbl_Hello;
    }
}