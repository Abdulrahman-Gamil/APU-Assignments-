﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trainer_final
{
    public partial class Main_Page : Form
    {

        private string username;
        
        public Main_Page(string username)
        {
            InitializeComponent();
            this.username = username;  
        }

        private void btn_Send_Feedback_Click(object sender, EventArgs e)
        {
            this.Hide();
            FeedBack FB = new FeedBack(username);
            FB.Show();
            
        }

        private void btn_Students_information_Click(object sender, EventArgs e)
        {
            this.Hide();
            Students_Information SI = new Students_Information();
            SI.Show();
        }

        private void btn_Update_My_Profile_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_Profile UP = new Update_Profile(username);
            UP.Show();
        }

        private void btn_Delete_Class_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }

        private void btn_Adding_New_Class_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_Update_Class_Click(object sender, EventArgs e)
        {
            this.Hide();
            Class_D CD = new Class_D();
            CD.Show();
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login LOG = new Login();
            LOG.Show();
        }

        private void lbl_Hello_Click(object sender, EventArgs e)
        {
            

        }

        private void Main_Page_Load(object sender, EventArgs e)
        {
            lbl_Hello.Text = "Hello " + username+" 😆";
        }
    }
}
