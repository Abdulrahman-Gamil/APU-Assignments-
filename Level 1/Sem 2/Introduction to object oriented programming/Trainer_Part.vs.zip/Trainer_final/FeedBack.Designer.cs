﻿namespace Trainer_final
{
    partial class FeedBack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Send = new System.Windows.Forms.Button();
            this.lbl_Send_Feedback = new System.Windows.Forms.Label();
            this.txtBox_Feedback = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(665, 403);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(123, 35);
            this.btn_Back.TabIndex = 28;
            this.btn_Back.Text = "Back.";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Send
            // 
            this.btn_Send.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Send.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Send.Location = new System.Drawing.Point(505, 403);
            this.btn_Send.Name = "btn_Send";
            this.btn_Send.Size = new System.Drawing.Size(123, 35);
            this.btn_Send.TabIndex = 29;
            this.btn_Send.Text = "Send.";
            this.btn_Send.UseVisualStyleBackColor = false;
            this.btn_Send.Click += new System.EventHandler(this.btn_Send_Click);
            // 
            // lbl_Send_Feedback
            // 
            this.lbl_Send_Feedback.AutoSize = true;
            this.lbl_Send_Feedback.Font = new System.Drawing.Font("Trebuchet MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Send_Feedback.Location = new System.Drawing.Point(262, 116);
            this.lbl_Send_Feedback.Name = "lbl_Send_Feedback";
            this.lbl_Send_Feedback.Size = new System.Drawing.Size(285, 28);
            this.lbl_Send_Feedback.TabIndex = 30;
            this.lbl_Send_Feedback.Text = "Send Feedback To Admin ";
            // 
            // txtBox_Feedback
            // 
            this.txtBox_Feedback.Location = new System.Drawing.Point(208, 223);
            this.txtBox_Feedback.Name = "txtBox_Feedback";
            this.txtBox_Feedback.Size = new System.Drawing.Size(391, 24);
            this.txtBox_Feedback.TabIndex = 31;
            // 
            // FeedBack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trainer_final.Properties.Resources.WhatsApp_Image_2023_06_04_at_17_51_59;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtBox_Feedback);
            this.Controls.Add(this.lbl_Send_Feedback);
            this.Controls.Add(this.btn_Send);
            this.Controls.Add(this.btn_Back);
            this.Name = "FeedBack";
            this.Text = "FeedBack";
            this.Load += new System.EventHandler(this.FeedBack_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Send;
        private System.Windows.Forms.Label lbl_Send_Feedback;
        private System.Windows.Forms.TextBox txtBox_Feedback;
    }
}