﻿namespace Trainer_final
{
    partial class Students_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.myDBDataSet = new Trainer_final.myDBDataSet();
            this.myDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.feedbackBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.feedbackTableAdapter = new Trainer_final.myDBDataSetTableAdapters.FeedbackTableAdapter();
            this.studentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.studentsTableAdapter = new Trainer_final.myDBDataSetTableAdapters.StudentsTableAdapter();
            this.studentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.studentsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.studentsBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.lbl_Student_Info = new System.Windows.Forms.Label();
            this.btn_Back = new System.Windows.Forms.Button();
            this.dataGridView_Students_Information = new System.Windows.Forms.DataGridView();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.levelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modulDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monthOfEnrollingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coachingStatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentsBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.myDBDataSet5 = new Trainer_final.myDBDataSet5();
            this.studentsTableAdapter1 = new Trainer_final.myDBDataSet5TableAdapters.StudentsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Students_Information)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet5)).BeginInit();
            this.SuspendLayout();
            // 
            // myDBDataSet
            // 
            this.myDBDataSet.DataSetName = "myDBDataSet";
            this.myDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // myDBDataSetBindingSource
            // 
            this.myDBDataSetBindingSource.DataSource = this.myDBDataSet;
            this.myDBDataSetBindingSource.Position = 0;
            // 
            // feedbackBindingSource
            // 
            this.feedbackBindingSource.DataMember = "Feedback";
            this.feedbackBindingSource.DataSource = this.myDBDataSetBindingSource;
            // 
            // feedbackTableAdapter
            // 
            this.feedbackTableAdapter.ClearBeforeFill = true;
            // 
            // studentsBindingSource
            // 
            this.studentsBindingSource.DataMember = "Students";
            this.studentsBindingSource.DataSource = this.myDBDataSetBindingSource;
            // 
            // studentsTableAdapter
            // 
            this.studentsTableAdapter.ClearBeforeFill = true;
            // 
            // studentsBindingSource1
            // 
            this.studentsBindingSource1.DataMember = "Students";
            this.studentsBindingSource1.DataSource = this.myDBDataSetBindingSource;
            // 
            // studentsBindingSource2
            // 
            this.studentsBindingSource2.DataMember = "Students";
            this.studentsBindingSource2.DataSource = this.myDBDataSetBindingSource;
            // 
            // studentsBindingSource3
            // 
            this.studentsBindingSource3.DataMember = "Students";
            this.studentsBindingSource3.DataSource = this.myDBDataSetBindingSource;
            // 
            // lbl_Student_Info
            // 
            this.lbl_Student_Info.AutoSize = true;
            this.lbl_Student_Info.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_Student_Info.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Info.Location = new System.Drawing.Point(42, 75);
            this.lbl_Student_Info.Name = "lbl_Student_Info";
            this.lbl_Student_Info.Size = new System.Drawing.Size(194, 23);
            this.lbl_Student_Info.TabIndex = 26;
            this.lbl_Student_Info.Text = "Students Information:";
            this.lbl_Student_Info.Click += new System.EventHandler(this.lbl_Student_Info_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(650, 387);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(123, 35);
            this.btn_Back.TabIndex = 27;
            this.btn_Back.Text = "Back.";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // dataGridView_Students_Information
            // 
            this.dataGridView_Students_Information.AllowUserToAddRows = false;
            this.dataGridView_Students_Information.AllowUserToDeleteRows = false;
            this.dataGridView_Students_Information.AutoGenerateColumns = false;
            this.dataGridView_Students_Information.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Students_Information.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.usernameDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.contactNumberDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.levelDataGridViewTextBoxColumn,
            this.modulDataGridViewTextBoxColumn,
            this.monthOfEnrollingDataGridViewTextBoxColumn,
            this.coachingStatusDataGridViewTextBoxColumn});
            this.dataGridView_Students_Information.DataSource = this.studentsBindingSource4;
            this.dataGridView_Students_Information.Location = new System.Drawing.Point(12, 148);
            this.dataGridView_Students_Information.Name = "dataGridView_Students_Information";
            this.dataGridView_Students_Information.ReadOnly = true;
            this.dataGridView_Students_Information.RowHeadersWidth = 51;
            this.dataGridView_Students_Information.RowTemplate.Height = 26;
            this.dataGridView_Students_Information.Size = new System.Drawing.Size(782, 150);
            this.dataGridView_Students_Information.TabIndex = 28;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "username";
            this.usernameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.usernameDataGridViewTextBoxColumn.Width = 125;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // contactNumberDataGridViewTextBoxColumn
            // 
            this.contactNumberDataGridViewTextBoxColumn.DataPropertyName = "ContactNumber ";
            this.contactNumberDataGridViewTextBoxColumn.HeaderText = "ContactNumber ";
            this.contactNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.contactNumberDataGridViewTextBoxColumn.Name = "contactNumberDataGridViewTextBoxColumn";
            this.contactNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.contactNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.ReadOnly = true;
            this.addressDataGridViewTextBoxColumn.Width = 125;
            // 
            // levelDataGridViewTextBoxColumn
            // 
            this.levelDataGridViewTextBoxColumn.DataPropertyName = "Level";
            this.levelDataGridViewTextBoxColumn.HeaderText = "Level";
            this.levelDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.levelDataGridViewTextBoxColumn.Name = "levelDataGridViewTextBoxColumn";
            this.levelDataGridViewTextBoxColumn.ReadOnly = true;
            this.levelDataGridViewTextBoxColumn.Width = 125;
            // 
            // modulDataGridViewTextBoxColumn
            // 
            this.modulDataGridViewTextBoxColumn.DataPropertyName = "Modul";
            this.modulDataGridViewTextBoxColumn.HeaderText = "Modul";
            this.modulDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.modulDataGridViewTextBoxColumn.Name = "modulDataGridViewTextBoxColumn";
            this.modulDataGridViewTextBoxColumn.ReadOnly = true;
            this.modulDataGridViewTextBoxColumn.Width = 125;
            // 
            // monthOfEnrollingDataGridViewTextBoxColumn
            // 
            this.monthOfEnrollingDataGridViewTextBoxColumn.DataPropertyName = "MonthOfEnrolling";
            this.monthOfEnrollingDataGridViewTextBoxColumn.HeaderText = "MonthOfEnrolling";
            this.monthOfEnrollingDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.monthOfEnrollingDataGridViewTextBoxColumn.Name = "monthOfEnrollingDataGridViewTextBoxColumn";
            this.monthOfEnrollingDataGridViewTextBoxColumn.ReadOnly = true;
            this.monthOfEnrollingDataGridViewTextBoxColumn.Width = 125;
            // 
            // coachingStatusDataGridViewTextBoxColumn
            // 
            this.coachingStatusDataGridViewTextBoxColumn.DataPropertyName = "CoachingStatus";
            this.coachingStatusDataGridViewTextBoxColumn.HeaderText = "CoachingStatus";
            this.coachingStatusDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.coachingStatusDataGridViewTextBoxColumn.Name = "coachingStatusDataGridViewTextBoxColumn";
            this.coachingStatusDataGridViewTextBoxColumn.ReadOnly = true;
            this.coachingStatusDataGridViewTextBoxColumn.Width = 125;
            // 
            // studentsBindingSource4
            // 
            this.studentsBindingSource4.DataMember = "Students";
            this.studentsBindingSource4.DataSource = this.myDBDataSet5;
            // 
            // myDBDataSet5
            // 
            this.myDBDataSet5.DataSetName = "myDBDataSet5";
            this.myDBDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentsTableAdapter1
            // 
            this.studentsTableAdapter1.ClearBeforeFill = true;
            // 
            // Students_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trainer_final.Properties.Resources.WhatsApp_Image_2023_06_04_at_17_51_59;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView_Students_Information);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lbl_Student_Info);
            this.Name = "Students_Information";
            this.Text = "Students_Information";
            this.Load += new System.EventHandler(this.Students_Information_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Students_Information)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentsBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private myDBDataSet myDBDataSet;
        private System.Windows.Forms.BindingSource myDBDataSetBindingSource;
        private System.Windows.Forms.BindingSource feedbackBindingSource;
        private myDBDataSetTableAdapters.FeedbackTableAdapter feedbackTableAdapter;
        private System.Windows.Forms.BindingSource studentsBindingSource;
        private myDBDataSetTableAdapters.StudentsTableAdapter studentsTableAdapter;
        private System.Windows.Forms.BindingSource studentsBindingSource1;
        private System.Windows.Forms.BindingSource studentsBindingSource2;
        private System.Windows.Forms.BindingSource studentsBindingSource3;
        private System.Windows.Forms.Label lbl_Student_Info;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.DataGridView dataGridView_Students_Information;
        private myDBDataSet5 myDBDataSet5;
        private System.Windows.Forms.BindingSource studentsBindingSource4;
        private myDBDataSet5TableAdapters.StudentsTableAdapter studentsTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn levelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modulDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn monthOfEnrollingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coachingStatusDataGridViewTextBoxColumn;
    }
}