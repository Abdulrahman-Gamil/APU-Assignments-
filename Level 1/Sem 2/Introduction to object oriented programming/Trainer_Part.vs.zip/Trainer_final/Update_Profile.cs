﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Trainer_final
{
    public partial class Update_Profile : Form
    {

        public string username;

        public Update_Profile(string username)
        {
            InitializeComponent();
            this.username = username;

        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            Main_Page mp = new Main_Page(username);
            mp.Show();
            this.Hide();
        }

        private void Update_Profile_Load(object sender, EventArgs e)
        {
            lbl_Name_.Text = username;
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Retrieve the Address, ContactNumber, Email, Module, and Level from the Trainer table
                SqlCommand selectCmd = new SqlCommand("SELECT Address, ContactNumber, Email, Module, Level FROM Trainer WHERE username = @Username", conn);
                selectCmd.Parameters.AddWithValue("@Username", username);

                conn.Open();

                using (SqlDataReader reader = selectCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        // Extract the values from the reader
                        string address = reader["Address"].ToString();
                        string contactNumber = reader["ContactNumber"].ToString();
                        string email = reader["Email"].ToString();
                        string module = reader["Module"].ToString();
                        string level = reader["Level"].ToString();

                        // Assign the retrieved values to the labels
                        lbl_Address.Text = address;
                        lbl_ContactNumber.Text = contactNumber;
                        lbl_Email.Text = email;
                        lbl_Module.Text = module;
                        lbl_Level.Text = level;
                    }
                }

                conn.Close();
            }

        }

        private void lbl_TP_Number__Click(object sender, EventArgs e)
        {

        }

        private void lbl_Name__Click(object sender, EventArgs e)
        {

        }

        private void btn_confirm_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf;Integrated Security=True";
            string newPassword = txtBox_Password.Text; // Retrieve the new password entered in the password textbox
            string username = lbl_Name_.Text; // Retrieve the username from the label

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Login SET Password = @Password WHERE Username = @Username", conn);
                cmd.Parameters.AddWithValue("@Password", newPassword); // Set the value of the @Password parameter in the SQL command to the new password
                cmd.Parameters.AddWithValue("@Username", username); // Set the value of the @Username parameter in the SQL command to the username

                conn.Open(); // Open the database connection
                int rowsAffected = cmd.ExecuteNonQuery(); // Execute the SQL command and get the number of rows affected by the update operation
                conn.Close(); // Close the database connection

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Password updated successfully", "Success"); // Display a success message if the password is updated successfully
                }
                else
                {
                    MessageBox.Show("Failed to update password", "Error"); // Display an error message if the password update fails
                }
            }



        }

        private void btn_Back_Click_1(object sender, EventArgs e)
        {
            Main_Page mp = new Main_Page(username);
            mp.Show();
            this.Hide();
        }

        private void lbl_show_Username_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btn_Chamge_Perssonal_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf;Integrated Security=True";
            string newEmail = txtBox_Email.Text;
            string newContactNumber = txtBox_ContactNumber.Text;
            string newAddress = txtBox_Address.Text;

            // Establish a connection to the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Construct the SQL command to update the Trainer table
                SqlCommand cmd = new SqlCommand("UPDATE Trainer SET Email = @Email, ContactNumber = @ContactNumber, Address = @Address WHERE username = @Username", conn);
                cmd.Parameters.AddWithValue("@Email", newEmail);
                cmd.Parameters.AddWithValue("@ContactNumber", newContactNumber);
                cmd.Parameters.AddWithValue("@Address", newAddress);
                cmd.Parameters.AddWithValue("@Username", username);

                // Open the database connection
                conn.Open();

                // Execute the SQL command and get the number of affected rows
                int rowsAffected = cmd.ExecuteNonQuery();

                // Close the database connection
                conn.Close();

                // Check if the update was successful
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Trainer information updated successfully");
                }
                else
                {
                    MessageBox.Show("Failed to update trainer information");
                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }  

}
