﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trainer_final
{

    public partial class Class_D : Form
    {
        private string username;
        // Define the connection string for the SqlConnection object.
        // The connection string specifies the data source, database file, and integrated security settings.
        // Adjust the file path and database name as per your specific setup.
        SqlConnection conn = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf;Integrated Security=True");

        public Class_D()
        {
            InitializeComponent();
            
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            // Transition to the Main_Page form, passing the username and hiding the current form
            Main_Page mp = new Main_Page(username);
            mp.Show();
            this.Hide();
        }

        private void Class_D_Load(object sender, EventArgs e)
        {
            // This line of code loads data into the 'myDBDataSet4.sch' table. You can move, or remove it, as needed.
            this.schTableAdapter3.Fill(this.myDBDataSet4.sch);
            // This line of code loads data into the 'myDBDataSet3.sch' table. You can move, or remove it, as needed.
            this.schTableAdapter2.Fill(this.myDBDataSet3.sch);
            // This line of code loads data into the 'myDBDataSet1.sch' table. You can move, or remove it, as needed.
            this.schTableAdapter1.Fill(this.myDBDataSet1.sch);
            //This line of code loads data into the 'myDBDataSet.sch' table. You can move, or remove it, as needed.
            this.schTableAdapter.Fill(this.myDBDataSet.sch);

        }

        private void btn_Adding_New_Class_Click(object sender, EventArgs e)
        {
            string moduleID = txtBox_ModuleID.Text;
            string className = txtBox_Class.Text;
            string time = txtBox_Time.Text;
            string day = txtBox_Day.Text;
            string fees = txtBox_Fees.Text;

            Class_Details classDManager = new Class_Details(conn.ConnectionString);
            classDManager.AddNewClass(moduleID, className, time, day, fees);

            // Clear the textbox values
            txtBox_ModuleID.Text = "";
            txtBox_Class.Text = "";
            txtBox_Time.Text = "";
            txtBox_Day.Text = "";
            txtBox_Fees.Text = "";

        }

        private void btn_Update_Class_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "UPDATE sch SET class = @class, time = @time, day = @day, fees = @fees WHERE ModuleID = @ModuleID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ModuleID", txtBox_ModuleID.Text);
                cmd.Parameters.AddWithValue("@class", txtBox_Class.Text);
                cmd.Parameters.AddWithValue("@time", txtBox_Time.Text);
                cmd.Parameters.AddWithValue("@day", txtBox_Class.Text);
                cmd.Parameters.AddWithValue("@fees", txtBox_Fees.Text);
                cmd.ExecuteNonQuery();
                conn.Close();

                // Display a success message
                MessageBox.Show("Updated ⬆️", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
            }
           
        }

        private void btn_Delete_Class_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string query = "DELETE FROM sch WHERE ModuleID = @ModuleID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ModuleID", txtBox_ModuleID.Text);
                cmd.ExecuteNonQuery();
                conn.Close();

                // Display a success message
                MessageBox.Show("Deleted 🪣", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
            }
        }
    }
}
