﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.AccessControl;
using System.Configuration;
using System.Reflection;


namespace Trainer_final
{
    internal class Class_Details
    {
        private SqlConnection conn;

        public Class_Details(string connectionString)
        {
            conn = new SqlConnection(connectionString);
        }

        public void AddNewClass(string moduleID, string className, string time, string day, string fees)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO sch (ModuleID, class, time, day, fees) VALUES (@ModuleID, @class, @time, @day, @fees)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ModuleID", moduleID);
                cmd.Parameters.AddWithValue("@class", className);
                cmd.Parameters.AddWithValue("@time", time);
                cmd.Parameters.AddWithValue("@day", day);
                cmd.Parameters.AddWithValue("@fees", fees);
                cmd.ExecuteNonQuery();
                conn.Close();

                // Display a success message
                MessageBox.Show("Recorded ✅", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
            }
        }

        public void UpdateClass(string moduleID, string className, string time, string day, string fees)
        {
            try
            {
                conn.Open();
                string query = "UPDATE sch SET class = @class, time = @time, day = @day, fees = @fees WHERE ModuleID = @ModuleID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ModuleID", moduleID);
                cmd.Parameters.AddWithValue("@class", className);
                cmd.Parameters.AddWithValue("@time", time);
                cmd.Parameters.AddWithValue("@day", day);
                cmd.Parameters.AddWithValue("@fees", fees);
                cmd.ExecuteNonQuery();
                conn.Close();

                // Display a success message
                MessageBox.Show("Updated ⬆️", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
            }
        }

        public void DeleteClass(string moduleID)
        {
            try
            {
                conn.Open();
                string query = "DELETE FROM sch WHERE ModuleID = @ModuleID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ModuleID", moduleID);
                cmd.ExecuteNonQuery();
                conn.Close();

                // Display a success message
                MessageBox.Show("Deleted 🪣", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                conn.Close();
            }
        }


    }
   

}


