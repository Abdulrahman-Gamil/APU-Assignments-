﻿namespace Trainer_final
{
    partial class Update_Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Name_ = new System.Windows.Forms.Label();
            this.txtBox_Address = new System.Windows.Forms.TextBox();
            this.txtBox_ContactNumber = new System.Windows.Forms.TextBox();
            this.txtBox_Email = new System.Windows.Forms.TextBox();
            this.btn_Change_Password = new System.Windows.Forms.Button();
            this.lbl_show_Username = new System.Windows.Forms.Label();
            this.lbl_Show_Email = new System.Windows.Forms.Label();
            this.lbl_ContactNumber_Show = new System.Windows.Forms.Label();
            this.lbl_Address_Show = new System.Windows.Forms.Label();
            this.lbl_New_Password = new System.Windows.Forms.Label();
            this.txtBox_Password = new System.Windows.Forms.TextBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.groupBox_Perssonal_Information = new System.Windows.Forms.GroupBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_ContactNumber = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_Module = new System.Windows.Forms.Label();
            this.lbl_Module_Show = new System.Windows.Forms.Label();
            this.lbl_Level = new System.Windows.Forms.Label();
            this.lbl_Level_Show = new System.Windows.Forms.Label();
            this.btn_Chamge_Perssonal = new System.Windows.Forms.Button();
            this.lbl_Photo_Profile = new System.Windows.Forms.Label();
            this.pictureBox_Profile = new System.Windows.Forms.PictureBox();
            this.groupBox_Perssonal_Information.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Profile)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Name_
            // 
            this.lbl_Name_.AutoSize = true;
            this.lbl_Name_.Location = new System.Drawing.Point(355, 34);
            this.lbl_Name_.Name = "lbl_Name_";
            this.lbl_Name_.Size = new System.Drawing.Size(15, 16);
            this.lbl_Name_.TabIndex = 0;
            this.lbl_Name_.Text = ". ";
            this.lbl_Name_.Click += new System.EventHandler(this.lbl_Name__Click);
            // 
            // txtBox_Address
            // 
            this.txtBox_Address.Location = new System.Drawing.Point(195, 230);
            this.txtBox_Address.Name = "txtBox_Address";
            this.txtBox_Address.Size = new System.Drawing.Size(125, 23);
            this.txtBox_Address.TabIndex = 2;
            // 
            // txtBox_ContactNumber
            // 
            this.txtBox_ContactNumber.Location = new System.Drawing.Point(195, 183);
            this.txtBox_ContactNumber.Name = "txtBox_ContactNumber";
            this.txtBox_ContactNumber.Size = new System.Drawing.Size(125, 23);
            this.txtBox_ContactNumber.TabIndex = 3;
            // 
            // txtBox_Email
            // 
            this.txtBox_Email.Location = new System.Drawing.Point(195, 144);
            this.txtBox_Email.Name = "txtBox_Email";
            this.txtBox_Email.Size = new System.Drawing.Size(125, 23);
            this.txtBox_Email.TabIndex = 4;
            // 
            // btn_Change_Password
            // 
            this.btn_Change_Password.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Change_Password.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Change_Password.Location = new System.Drawing.Point(29, 362);
            this.btn_Change_Password.Name = "btn_Change_Password";
            this.btn_Change_Password.Size = new System.Drawing.Size(140, 33);
            this.btn_Change_Password.TabIndex = 5;
            this.btn_Change_Password.Text = "Change Password.";
            this.btn_Change_Password.UseVisualStyleBackColor = false;
            this.btn_Change_Password.Click += new System.EventHandler(this.btn_confirm_Click);
            // 
            // lbl_show_Username
            // 
            this.lbl_show_Username.AutoSize = true;
            this.lbl_show_Username.Location = new System.Drawing.Point(14, 34);
            this.lbl_show_Username.Name = "lbl_show_Username";
            this.lbl_show_Username.Size = new System.Drawing.Size(76, 16);
            this.lbl_show_Username.TabIndex = 6;
            this.lbl_show_Username.Text = "Username:";
            this.lbl_show_Username.Click += new System.EventHandler(this.lbl_show_Username_Click);
            // 
            // lbl_Show_Email
            // 
            this.lbl_Show_Email.AutoSize = true;
            this.lbl_Show_Email.Location = new System.Drawing.Point(16, 144);
            this.lbl_Show_Email.Name = "lbl_Show_Email";
            this.lbl_Show_Email.Size = new System.Drawing.Size(44, 16);
            this.lbl_Show_Email.TabIndex = 7;
            this.lbl_Show_Email.Text = "Email:";
            // 
            // lbl_ContactNumber_Show
            // 
            this.lbl_ContactNumber_Show.AutoSize = true;
            this.lbl_ContactNumber_Show.Location = new System.Drawing.Point(16, 183);
            this.lbl_ContactNumber_Show.Name = "lbl_ContactNumber_Show";
            this.lbl_ContactNumber_Show.Size = new System.Drawing.Size(110, 16);
            this.lbl_ContactNumber_Show.TabIndex = 8;
            this.lbl_ContactNumber_Show.Text = "Conact Number:";
            // 
            // lbl_Address_Show
            // 
            this.lbl_Address_Show.AutoSize = true;
            this.lbl_Address_Show.Location = new System.Drawing.Point(16, 230);
            this.lbl_Address_Show.Name = "lbl_Address_Show";
            this.lbl_Address_Show.Size = new System.Drawing.Size(66, 16);
            this.lbl_Address_Show.TabIndex = 9;
            this.lbl_Address_Show.Text = "Address:";
            // 
            // lbl_New_Password
            // 
            this.lbl_New_Password.AutoSize = true;
            this.lbl_New_Password.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Password.Location = new System.Drawing.Point(284, 298);
            this.lbl_New_Password.Name = "lbl_New_Password";
            this.lbl_New_Password.Size = new System.Drawing.Size(106, 16);
            this.lbl_New_Password.TabIndex = 11;
            this.lbl_New_Password.Text = "New Password:";
            // 
            // txtBox_Password
            // 
            this.txtBox_Password.Location = new System.Drawing.Point(626, 298);
            this.txtBox_Password.Name = "txtBox_Password";
            this.txtBox_Password.Size = new System.Drawing.Size(100, 24);
            this.txtBox_Password.TabIndex = 10;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(665, 362);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(123, 35);
            this.btn_Back.TabIndex = 35;
            this.btn_Back.Text = "Back.";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click_1);
            // 
            // groupBox_Perssonal_Information
            // 
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Address);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_ContactNumber);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Email);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Module);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Module_Show);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Level);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Name_);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Level_Show);
            this.groupBox_Perssonal_Information.Controls.Add(this.txtBox_Address);
            this.groupBox_Perssonal_Information.Controls.Add(this.txtBox_ContactNumber);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Address_Show);
            this.groupBox_Perssonal_Information.Controls.Add(this.txtBox_Email);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_ContactNumber_Show);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_show_Username);
            this.groupBox_Perssonal_Information.Controls.Add(this.lbl_Show_Email);
            this.groupBox_Perssonal_Information.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_Perssonal_Information.Location = new System.Drawing.Point(268, 18);
            this.groupBox_Perssonal_Information.Name = "groupBox_Perssonal_Information";
            this.groupBox_Perssonal_Information.Size = new System.Drawing.Size(520, 264);
            this.groupBox_Perssonal_Information.TabIndex = 36;
            this.groupBox_Perssonal_Information.TabStop = false;
            this.groupBox_Perssonal_Information.Text = "Personal Information";
            this.groupBox_Perssonal_Information.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Location = new System.Drawing.Point(355, 230);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(15, 16);
            this.lbl_Address.TabIndex = 44;
            this.lbl_Address.Text = ". ";
            // 
            // lbl_ContactNumber
            // 
            this.lbl_ContactNumber.AutoSize = true;
            this.lbl_ContactNumber.Location = new System.Drawing.Point(355, 187);
            this.lbl_ContactNumber.Name = "lbl_ContactNumber";
            this.lbl_ContactNumber.Size = new System.Drawing.Size(15, 16);
            this.lbl_ContactNumber.TabIndex = 43;
            this.lbl_ContactNumber.Text = ". ";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Location = new System.Drawing.Point(355, 144);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(15, 16);
            this.lbl_Email.TabIndex = 42;
            this.lbl_Email.Text = ". ";
            this.lbl_Email.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbl_Module
            // 
            this.lbl_Module.AutoSize = true;
            this.lbl_Module.Location = new System.Drawing.Point(357, 108);
            this.lbl_Module.Name = "lbl_Module";
            this.lbl_Module.Size = new System.Drawing.Size(15, 16);
            this.lbl_Module.TabIndex = 40;
            this.lbl_Module.Text = ". ";
            // 
            // lbl_Module_Show
            // 
            this.lbl_Module_Show.AutoSize = true;
            this.lbl_Module_Show.Location = new System.Drawing.Point(16, 108);
            this.lbl_Module_Show.Name = "lbl_Module_Show";
            this.lbl_Module_Show.Size = new System.Drawing.Size(58, 16);
            this.lbl_Module_Show.TabIndex = 41;
            this.lbl_Module_Show.Text = "Module:";
            // 
            // lbl_Level
            // 
            this.lbl_Level.AutoSize = true;
            this.lbl_Level.Location = new System.Drawing.Point(355, 68);
            this.lbl_Level.Name = "lbl_Level";
            this.lbl_Level.Size = new System.Drawing.Size(15, 16);
            this.lbl_Level.TabIndex = 38;
            this.lbl_Level.Text = ". ";
            // 
            // lbl_Level_Show
            // 
            this.lbl_Level_Show.AutoSize = true;
            this.lbl_Level_Show.Location = new System.Drawing.Point(14, 68);
            this.lbl_Level_Show.Name = "lbl_Level_Show";
            this.lbl_Level_Show.Size = new System.Drawing.Size(46, 16);
            this.lbl_Level_Show.TabIndex = 39;
            this.lbl_Level_Show.Text = "Level:";
            // 
            // btn_Chamge_Perssonal
            // 
            this.btn_Chamge_Perssonal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Chamge_Perssonal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Chamge_Perssonal.Location = new System.Drawing.Point(198, 362);
            this.btn_Chamge_Perssonal.Name = "btn_Chamge_Perssonal";
            this.btn_Chamge_Perssonal.Size = new System.Drawing.Size(212, 33);
            this.btn_Chamge_Perssonal.TabIndex = 37;
            this.btn_Chamge_Perssonal.Text = "Change Personal Information .";
            this.btn_Chamge_Perssonal.UseVisualStyleBackColor = false;
            this.btn_Chamge_Perssonal.Click += new System.EventHandler(this.btn_Chamge_Perssonal_Click);
            // 
            // lbl_Photo_Profile
            // 
            this.lbl_Photo_Profile.AutoSize = true;
            this.lbl_Photo_Profile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_Photo_Profile.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Photo_Profile.Location = new System.Drawing.Point(21, 16);
            this.lbl_Photo_Profile.Name = "lbl_Photo_Profile";
            this.lbl_Photo_Profile.Size = new System.Drawing.Size(155, 19);
            this.lbl_Photo_Profile.TabIndex = 39;
            this.lbl_Photo_Profile.Text = "Your Profile Photo:";
            // 
            // pictureBox_Profile
            // 
            this.pictureBox_Profile.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox_Profile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox_Profile.Image = global::Trainer_final.Properties.Resources.تنزيل;
            this.pictureBox_Profile.Location = new System.Drawing.Point(21, 48);
            this.pictureBox_Profile.Name = "pictureBox_Profile";
            this.pictureBox_Profile.Size = new System.Drawing.Size(220, 204);
            this.pictureBox_Profile.TabIndex = 38;
            this.pictureBox_Profile.TabStop = false;
            // 
            // Update_Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trainer_final.Properties.Resources.WhatsApp_Image_2023_06_04_at_17_51_59;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 410);
            this.Controls.Add(this.lbl_Photo_Profile);
            this.Controls.Add(this.pictureBox_Profile);
            this.Controls.Add(this.btn_Chamge_Perssonal);
            this.Controls.Add(this.txtBox_Password);
            this.Controls.Add(this.groupBox_Perssonal_Information);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.lbl_New_Password);
            this.Controls.Add(this.btn_Change_Password);
            this.Name = "Update_Profile";
            this.Text = "Update_Profile";
            this.Load += new System.EventHandler(this.Update_Profile_Load);
            this.groupBox_Perssonal_Information.ResumeLayout(false);
            this.groupBox_Perssonal_Information.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Profile)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Name_;
        private System.Windows.Forms.TextBox txtBox_Address;
        private System.Windows.Forms.TextBox txtBox_ContactNumber;
        private System.Windows.Forms.TextBox txtBox_Email;
        private System.Windows.Forms.Button btn_Change_Password;
        private System.Windows.Forms.Label lbl_show_Username;
        private System.Windows.Forms.Label lbl_Show_Email;
        private System.Windows.Forms.Label lbl_ContactNumber_Show;
        private System.Windows.Forms.Label lbl_Address_Show;
        private System.Windows.Forms.Label lbl_New_Password;
        private System.Windows.Forms.TextBox txtBox_Password;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.GroupBox groupBox_Perssonal_Information;
        private System.Windows.Forms.Button btn_Chamge_Perssonal;
        private System.Windows.Forms.Label lbl_Module;
        private System.Windows.Forms.Label lbl_Module_Show;
        private System.Windows.Forms.Label lbl_Level;
        private System.Windows.Forms.Label lbl_Level_Show;
        private System.Windows.Forms.Label lbl_Photo_Profile;
        private System.Windows.Forms.PictureBox pictureBox_Profile;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_ContactNumber;
        private System.Windows.Forms.Label lbl_Email;
    }
}