﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trainer_final
{
    public partial class Students_Information : Form
    {
        private string username;
        public Students_Information()
        {
            InitializeComponent();
        }

        private void Students_Information_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'myDBDataSet5.Students' table. You can move, or remove it, as needed.
            this.studentsTableAdapter1.Fill(this.myDBDataSet5.Students);


        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            
            Main_Page mp = new Main_Page(username);
            mp.Show();
            this.Hide();
        }

        private void lbl_Student_Info_Click(object sender, EventArgs e)
        {

        }
    }
}
