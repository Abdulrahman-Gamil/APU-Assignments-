﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.AccessControl;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using static Trainer_final.Login_Class;

namespace Trainer_final
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        // Event handler for the login button click event
        private void btn_Login_Click(object sender, EventArgs e)
        {
            // Set up the connection string
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\96656\\Desktop\\Trainer_final\\Trainer_final\\myDB.mdf;Integrated Security=True";

            // Create an instance of the LoginManager class with the connection string
            LoginManager loginManager = new LoginManager(connectionString);

            // Retrieve the username and password from the textboxes
            string username = txtBox_Username.Text;
            string password = txtBox_Password.Text;

            // Authenticate the user using the LoginManager
            bool isAuthenticated = loginManager.Authenticate(username, password);

            if (isAuthenticated)
            {
                // Successful login: Display the main page
                new Main_Page(username).Show();
                this.Hide();
            }
            else
            {
                // Invalid username or password: Show error message and clear input fields
                MessageBox.Show("Username or password is invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtBox_Username.Focus();
            }
        }

        // Event handler for the exit button click event
        private void btn_Exit_Click(object sender, EventArgs e)
        {
            // Terminate the application and close all windows and processes
            Application.Exit();
        }

        // Event handler for the clear button click event
        private void btn_Clear_Click(object sender, EventArgs e)
        {
            // Clear the username and password textboxes
            txtBox_Username.Clear();
            txtBox_Password.Clear();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }

       
   
}
