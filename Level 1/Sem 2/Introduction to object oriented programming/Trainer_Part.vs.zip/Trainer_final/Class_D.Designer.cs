﻿namespace Trainer_final
{
    partial class Class_D
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_Update_Class = new System.Windows.Forms.Button();
            this.btn_Delete_Class = new System.Windows.Forms.Button();
            this.btn_Adding_New_Class = new System.Windows.Forms.Button();
            this.btn_Back = new System.Windows.Forms.Button();
            this.myDBDataSet = new Trainer_final.myDBDataSet();
            this.schBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schTableAdapter = new Trainer_final.myDBDataSetTableAdapters.schTableAdapter();
            this.lbl_Time = new System.Windows.Forms.Label();
            this.lbl_Day = new System.Windows.Forms.Label();
            this.lbl_Class = new System.Windows.Forms.Label();
            this.lbl_ModuleID = new System.Windows.Forms.Label();
            this.txtBox_Class = new System.Windows.Forms.TextBox();
            this.txtBox_Day = new System.Windows.Forms.TextBox();
            this.txtBox_Time = new System.Windows.Forms.TextBox();
            this.txtBox_ModuleID = new System.Windows.Forms.TextBox();
            this.myDBDataSet1 = new Trainer_final.myDBDataSet1();
            this.schBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.schTableAdapter1 = new Trainer_final.myDBDataSet1TableAdapters.schTableAdapter();
            this.myDBDataSet3 = new Trainer_final.myDBDataSet3();
            this.schBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.schTableAdapter2 = new Trainer_final.myDBDataSet3TableAdapters.schTableAdapter();
            this.txtBox_Fees = new System.Windows.Forms.TextBox();
            this.lbl_Message = new System.Windows.Forms.Label();
            this.lbl_Fees = new System.Windows.Forms.Label();
            this.schBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView_Class = new System.Windows.Forms.DataGridView();
            this.moduleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.schBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.myDBDataSet4 = new Trainer_final.myDBDataSet4();
            this.schTableAdapter3 = new Trainer_final.myDBDataSet4TableAdapters.schTableAdapter();
            this.lbl_Classes = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Class)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Update_Class
            // 
            this.btn_Update_Class.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Update_Class.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update_Class.Location = new System.Drawing.Point(148, 470);
            this.btn_Update_Class.Name = "btn_Update_Class";
            this.btn_Update_Class.Size = new System.Drawing.Size(114, 59);
            this.btn_Update_Class.TabIndex = 33;
            this.btn_Update_Class.Text = "Updating Class.";
            this.btn_Update_Class.UseVisualStyleBackColor = false;
            this.btn_Update_Class.Click += new System.EventHandler(this.btn_Update_Class_Click);
            // 
            // btn_Delete_Class
            // 
            this.btn_Delete_Class.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Delete_Class.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete_Class.Location = new System.Drawing.Point(282, 470);
            this.btn_Delete_Class.Name = "btn_Delete_Class";
            this.btn_Delete_Class.Size = new System.Drawing.Size(114, 59);
            this.btn_Delete_Class.TabIndex = 32;
            this.btn_Delete_Class.Text = "Delete Class.";
            this.btn_Delete_Class.UseVisualStyleBackColor = false;
            this.btn_Delete_Class.Click += new System.EventHandler(this.btn_Delete_Class_Click);
            // 
            // btn_Adding_New_Class
            // 
            this.btn_Adding_New_Class.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Adding_New_Class.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Adding_New_Class.Location = new System.Drawing.Point(28, 470);
            this.btn_Adding_New_Class.Name = "btn_Adding_New_Class";
            this.btn_Adding_New_Class.Size = new System.Drawing.Size(114, 59);
            this.btn_Adding_New_Class.TabIndex = 31;
            this.btn_Adding_New_Class.Text = "Adding New Class.";
            this.btn_Adding_New_Class.UseVisualStyleBackColor = false;
            this.btn_Adding_New_Class.Click += new System.EventHandler(this.btn_Adding_New_Class_Click);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_Back.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.Location = new System.Drawing.Point(584, 494);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(123, 35);
            this.btn_Back.TabIndex = 34;
            this.btn_Back.Text = "Back.";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // myDBDataSet
            // 
            this.myDBDataSet.DataSetName = "myDBDataSet";
            this.myDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schBindingSource
            // 
            this.schBindingSource.DataMember = "sch";
            this.schBindingSource.DataSource = this.myDBDataSet;
            // 
            // schTableAdapter
            // 
            this.schTableAdapter.ClearBeforeFill = true;
            // 
            // lbl_Time
            // 
            this.lbl_Time.AutoSize = true;
            this.lbl_Time.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time.Location = new System.Drawing.Point(27, 325);
            this.lbl_Time.Name = "lbl_Time";
            this.lbl_Time.Size = new System.Drawing.Size(61, 22);
            this.lbl_Time.TabIndex = 36;
            this.lbl_Time.Text = "Time: ";
            // 
            // lbl_Day
            // 
            this.lbl_Day.AutoSize = true;
            this.lbl_Day.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Day.Location = new System.Drawing.Point(27, 366);
            this.lbl_Day.Name = "lbl_Day";
            this.lbl_Day.Size = new System.Drawing.Size(48, 22);
            this.lbl_Day.TabIndex = 37;
            this.lbl_Day.Text = "Day:";
            // 
            // lbl_Class
            // 
            this.lbl_Class.AutoSize = true;
            this.lbl_Class.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Class.Location = new System.Drawing.Point(27, 286);
            this.lbl_Class.Name = "lbl_Class";
            this.lbl_Class.Size = new System.Drawing.Size(60, 22);
            this.lbl_Class.TabIndex = 38;
            this.lbl_Class.Text = "Class:";
            // 
            // lbl_ModuleID
            // 
            this.lbl_ModuleID.AutoSize = true;
            this.lbl_ModuleID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModuleID.Location = new System.Drawing.Point(27, 246);
            this.lbl_ModuleID.Name = "lbl_ModuleID";
            this.lbl_ModuleID.Size = new System.Drawing.Size(97, 22);
            this.lbl_ModuleID.TabIndex = 39;
            this.lbl_ModuleID.Text = "ModuleID:";
            // 
            // txtBox_Class
            // 
            this.txtBox_Class.Location = new System.Drawing.Point(147, 286);
            this.txtBox_Class.Name = "txtBox_Class";
            this.txtBox_Class.Size = new System.Drawing.Size(100, 24);
            this.txtBox_Class.TabIndex = 41;
            // 
            // txtBox_Day
            // 
            this.txtBox_Day.Location = new System.Drawing.Point(144, 370);
            this.txtBox_Day.Name = "txtBox_Day";
            this.txtBox_Day.Size = new System.Drawing.Size(100, 24);
            this.txtBox_Day.TabIndex = 42;
            // 
            // txtBox_Time
            // 
            this.txtBox_Time.Location = new System.Drawing.Point(145, 326);
            this.txtBox_Time.Name = "txtBox_Time";
            this.txtBox_Time.Size = new System.Drawing.Size(100, 24);
            this.txtBox_Time.TabIndex = 43;
            // 
            // txtBox_ModuleID
            // 
            this.txtBox_ModuleID.Location = new System.Drawing.Point(145, 247);
            this.txtBox_ModuleID.Name = "txtBox_ModuleID";
            this.txtBox_ModuleID.Size = new System.Drawing.Size(100, 24);
            this.txtBox_ModuleID.TabIndex = 44;
            // 
            // myDBDataSet1
            // 
            this.myDBDataSet1.DataSetName = "myDBDataSet1";
            this.myDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schBindingSource1
            // 
            this.schBindingSource1.DataMember = "sch";
            this.schBindingSource1.DataSource = this.myDBDataSet1;
            // 
            // schTableAdapter1
            // 
            this.schTableAdapter1.ClearBeforeFill = true;
            // 
            // myDBDataSet3
            // 
            this.myDBDataSet3.DataSetName = "myDBDataSet3";
            this.myDBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schBindingSource2
            // 
            this.schBindingSource2.DataMember = "sch";
            this.schBindingSource2.DataSource = this.myDBDataSet3;
            // 
            // schTableAdapter2
            // 
            this.schTableAdapter2.ClearBeforeFill = true;
            // 
            // txtBox_Fees
            // 
            this.txtBox_Fees.Location = new System.Drawing.Point(144, 411);
            this.txtBox_Fees.Name = "txtBox_Fees";
            this.txtBox_Fees.Size = new System.Drawing.Size(100, 24);
            this.txtBox_Fees.TabIndex = 45;
            // 
            // lbl_Message
            // 
            this.lbl_Message.AutoSize = true;
            this.lbl_Message.Font = new System.Drawing.Font("Tempus Sans ITC", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Message.Location = new System.Drawing.Point(451, 325);
            this.lbl_Message.Name = "lbl_Message";
            this.lbl_Message.Size = new System.Drawing.Size(0, 43);
            this.lbl_Message.TabIndex = 46;
            this.lbl_Message.Visible = false;
            // 
            // lbl_Fees
            // 
            this.lbl_Fees.AutoSize = true;
            this.lbl_Fees.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fees.Location = new System.Drawing.Point(27, 407);
            this.lbl_Fees.Name = "lbl_Fees";
            this.lbl_Fees.Size = new System.Drawing.Size(53, 22);
            this.lbl_Fees.TabIndex = 47;
            this.lbl_Fees.Text = "Fees:";
            // 
            // schBindingSource3
            // 
            this.schBindingSource3.DataMember = "sch";
            this.schBindingSource3.DataSource = this.myDBDataSet;
            // 
            // dataGridView_Class
            // 
            this.dataGridView_Class.AutoGenerateColumns = false;
            this.dataGridView_Class.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Class.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.moduleIDDataGridViewTextBoxColumn,
            this.classDataGridViewTextBoxColumn,
            this.timeDataGridViewTextBoxColumn,
            this.dayDataGridViewTextBoxColumn,
            this.feesDataGridViewTextBoxColumn});
            this.dataGridView_Class.DataSource = this.schBindingSource4;
            this.dataGridView_Class.Location = new System.Drawing.Point(29, 69);
            this.dataGridView_Class.Name = "dataGridView_Class";
            this.dataGridView_Class.RowHeadersWidth = 51;
            this.dataGridView_Class.RowTemplate.Height = 26;
            this.dataGridView_Class.Size = new System.Drawing.Size(678, 150);
            this.dataGridView_Class.TabIndex = 48;
            // 
            // moduleIDDataGridViewTextBoxColumn
            // 
            this.moduleIDDataGridViewTextBoxColumn.DataPropertyName = "ModuleID";
            this.moduleIDDataGridViewTextBoxColumn.HeaderText = "ModuleID";
            this.moduleIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.moduleIDDataGridViewTextBoxColumn.Name = "moduleIDDataGridViewTextBoxColumn";
            this.moduleIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // classDataGridViewTextBoxColumn
            // 
            this.classDataGridViewTextBoxColumn.DataPropertyName = "class";
            this.classDataGridViewTextBoxColumn.HeaderText = "class";
            this.classDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.classDataGridViewTextBoxColumn.Name = "classDataGridViewTextBoxColumn";
            this.classDataGridViewTextBoxColumn.Width = 125;
            // 
            // timeDataGridViewTextBoxColumn
            // 
            this.timeDataGridViewTextBoxColumn.DataPropertyName = "time";
            this.timeDataGridViewTextBoxColumn.HeaderText = "time";
            this.timeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.timeDataGridViewTextBoxColumn.Name = "timeDataGridViewTextBoxColumn";
            this.timeDataGridViewTextBoxColumn.Width = 125;
            // 
            // dayDataGridViewTextBoxColumn
            // 
            this.dayDataGridViewTextBoxColumn.DataPropertyName = "day ";
            this.dayDataGridViewTextBoxColumn.HeaderText = "day ";
            this.dayDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dayDataGridViewTextBoxColumn.Name = "dayDataGridViewTextBoxColumn";
            this.dayDataGridViewTextBoxColumn.Width = 125;
            // 
            // feesDataGridViewTextBoxColumn
            // 
            this.feesDataGridViewTextBoxColumn.DataPropertyName = "Fees";
            this.feesDataGridViewTextBoxColumn.HeaderText = "Fees";
            this.feesDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.feesDataGridViewTextBoxColumn.Name = "feesDataGridViewTextBoxColumn";
            this.feesDataGridViewTextBoxColumn.Width = 125;
            // 
            // schBindingSource4
            // 
            this.schBindingSource4.DataMember = "sch";
            this.schBindingSource4.DataSource = this.myDBDataSet4;
            // 
            // myDBDataSet4
            // 
            this.myDBDataSet4.DataSetName = "myDBDataSet4";
            this.myDBDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schTableAdapter3
            // 
            this.schTableAdapter3.ClearBeforeFill = true;
            // 
            // lbl_Classes
            // 
            this.lbl_Classes.AutoSize = true;
            this.lbl_Classes.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_Classes.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Classes.Location = new System.Drawing.Point(25, 30);
            this.lbl_Classes.Name = "lbl_Classes";
            this.lbl_Classes.Size = new System.Drawing.Size(163, 23);
            this.lbl_Classes.TabIndex = 49;
            this.lbl_Classes.Text = "Available Classes:";
            // 
            // Class_D
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Trainer_final.Properties.Resources.WhatsApp_Image_2023_06_04_at_17_51_59;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(736, 544);
            this.Controls.Add(this.lbl_Classes);
            this.Controls.Add(this.dataGridView_Class);
            this.Controls.Add(this.lbl_Fees);
            this.Controls.Add(this.lbl_Message);
            this.Controls.Add(this.txtBox_Fees);
            this.Controls.Add(this.txtBox_ModuleID);
            this.Controls.Add(this.txtBox_Time);
            this.Controls.Add(this.txtBox_Day);
            this.Controls.Add(this.txtBox_Class);
            this.Controls.Add(this.lbl_ModuleID);
            this.Controls.Add(this.lbl_Class);
            this.Controls.Add(this.lbl_Day);
            this.Controls.Add(this.lbl_Time);
            this.Controls.Add(this.btn_Back);
            this.Controls.Add(this.btn_Update_Class);
            this.Controls.Add(this.btn_Delete_Class);
            this.Controls.Add(this.btn_Adding_New_Class);
            this.Name = "Class_D";
            this.Text = "Class_D";
            this.Load += new System.EventHandler(this.Class_D_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Class)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myDBDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Update_Class;
        private System.Windows.Forms.Button btn_Delete_Class;
        private System.Windows.Forms.Button btn_Adding_New_Class;
        private System.Windows.Forms.Button btn_Back;
        private myDBDataSet myDBDataSet;
        private System.Windows.Forms.BindingSource schBindingSource;
        private myDBDataSetTableAdapters.schTableAdapter schTableAdapter;
        private System.Windows.Forms.Label lbl_Time;
        private System.Windows.Forms.Label lbl_Day;
        private System.Windows.Forms.Label lbl_Class;
        private System.Windows.Forms.Label lbl_ModuleID;
        private System.Windows.Forms.TextBox txtBox_Class;
        private System.Windows.Forms.TextBox txtBox_Day;
        private System.Windows.Forms.TextBox txtBox_Time;
        private System.Windows.Forms.TextBox txtBox_ModuleID;
        private myDBDataSet1 myDBDataSet1;
        private System.Windows.Forms.BindingSource schBindingSource1;
        private myDBDataSet1TableAdapters.schTableAdapter schTableAdapter1;
        private myDBDataSet3 myDBDataSet3;
        private System.Windows.Forms.BindingSource schBindingSource2;
        private myDBDataSet3TableAdapters.schTableAdapter schTableAdapter2;
        private System.Windows.Forms.TextBox txtBox_Fees;
        private System.Windows.Forms.Label lbl_Message;
        private System.Windows.Forms.Label lbl_Fees;
        private System.Windows.Forms.BindingSource schBindingSource3;
        private System.Windows.Forms.DataGridView dataGridView_Class;
        private myDBDataSet4 myDBDataSet4;
        private System.Windows.Forms.BindingSource schBindingSource4;
        private myDBDataSet4TableAdapters.schTableAdapter schTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn moduleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn classDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feesDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbl_Classes;
    }
}