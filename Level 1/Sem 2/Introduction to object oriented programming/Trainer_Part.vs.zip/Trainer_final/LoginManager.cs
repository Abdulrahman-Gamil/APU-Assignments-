﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trainer_final
{
    public class LoginManager
    {
        private SqlConnection conn;

        // Constructor for LoginManager class that takes the connection string as a parameter
        public LoginManager(string connectionString)
        {
            // Create a new instance of SqlConnection using the provided connection string
            conn = new SqlConnection(connectionString);
        }

        // Method to authenticate a user given the username and password
        public bool Authenticate(string username, string password)
        {
            try
            {
                conn.Open();

                // SQL query to select records from the Login table where the username and password match the provided values
                string query = "SELECT * FROM Login WHERE Username = @Username AND Password = @Password AND role = 'Trainer'";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                // Use SqlDataAdapter to fill a DataTable with the results of the query
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dtable = new DataTable();
                sda.Fill(dtable);

                conn.Close();

                // Return true if there is at least one row in the DataTable, indicating a successful authentication
                return (dtable.Rows.Count > 0);
            }
            catch (Exception ex)
            {
                // Display an error message if an exception occurs during the authentication process
                MessageBox.Show("Error");
                conn.Close();
                return false;
            }
        }
    }
}
